
import React, { useMemo } from 'react';
import { AppDataItem, ModuleType } from '../../types';

interface HomeScreenProps {
    openModule: (moduleType: ModuleType) => void;
    appData: AppDataItem[];
    emotionRecords: AppDataItem[];
}

const menuItems = [
    { type: 'smart-break', icon: '⏸️', title: 'Trò chơi', subtitle: 'Thư giãn', bg: 'from-blue-400 to-blue-600', rotate: 'rotate-3' },
    { type: 'zen-room', icon: '🧘', title: 'Phòng Zen', subtitle: 'Thiền định', bg: 'from-green-400 to-green-600', rotate: '-rotate-2' },
    { type: 'emotion-map', icon: '😊', title: 'Cảm xúc', subtitle: 'Chia sẻ', bg: 'from-yellow-400 to-orange-500', rotate: 'rotate-1' },
    { type: 'mission-5', icon: '🎯', title: 'Mission 5′', subtitle: 'Thử thách', bg: 'from-red-400 to-pink-500', rotate: '-rotate-1' },
    { type: 'happy-week', icon: '🌈', title: 'Happy Week', subtitle: 'Lễ hội', bg: 'from-purple-400 to-indigo-500', rotate: 'rotate-2' },
];

const getActivityIcon = (type: AppDataItem['type']) => {
    const icons: Record<string, string> = {
        'smart-break': '⏸️', 'zen-room': '🧘', 'emotion': '💬', 'emotion_record': '😊', 
        'mission': '🎯', 'happy-week': '🌈', 'student_login': '👋'
    };
    return icons[type] || '📝';
};

const HappinessEnergyCircle: React.FC<{ emotionRecords: AppDataItem[] }> = ({ emotionRecords }) => {
    const { positiveScore, stressScore, overallScore } = useMemo(() => {
        if (emotionRecords.length === 0) return { positiveScore: 0, stressScore: 0, overallScore: 85 };

        const counts = { 'very-happy': 0, 'happy': 0, 'stressed': 0 };
        emotionRecords.forEach(r => {
            if (r.emotion && r.emotion in counts) {
                counts[r.emotion as keyof typeof counts]++;
            }
        });

        const total = emotionRecords.length;
        const pScore = Math.round(((counts['very-happy'] + counts['happy']) / total) * 100);
        const sScore = Math.round((counts['stressed'] / total) * 100);
        const oScore = Math.max(pScore, 70); // Minimum 70% to keep positive

        return { positiveScore: pScore, stressScore: sScore, overallScore: oScore };
    }, [emotionRecords]);

    return (
         <div className="relative inline-block">
             <div className="w-48 h-48 mx-auto bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-2xl pulse-glow">
                 <div className="text-center text-white">
                     <div className="text-6xl mb-2">🌟</div>
                     <div className="text-lg font-bold">Chỉ số hạnh phúc</div>
                     <div className="text-sm opacity-90">học tập hôm nay</div>
                     <div className="mt-2">
                         <div className="text-2xl font-bold">{overallScore}%</div>
                         <div className="text-xs">Tích cực: <span>{positiveScore}%</span> | Căng thẳng: <span>{stressScore}%</span></div>
                     </div>
                 </div>
             </div>
         </div>
    );
};


export const HomeScreen: React.FC<HomeScreenProps> = ({ openModule, appData, emotionRecords }) => {
    const recentActivities = [...appData].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 5);

    return (
        <div id="home-screen">
            <div className="text-center mb-8">
                <HappinessEnergyCircle emotionRecords={emotionRecords} />
            </div>

            <div className="flex justify-center mb-8">
                <div className="relative w-full max-w-4xl">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-100 via-pink-50 to-blue-100 rounded-3xl opacity-60"></div>
                    <div className="absolute inset-2 bg-gradient-to-tr from-blue-50 via-white to-purple-50 rounded-2xl shadow-inner"></div>
                    <div className="relative p-8">
                        <div className="text-center mb-8">
                            <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">✨ Khám phá thế giới học tập ✨</h2>
                            <p className="text-gray-600">Chọn hoạt động yêu thích để bắt đầu hành trình!</p>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
                            {menuItems.map(item => (
                                <div key={item.type} className="group relative" onClick={() => openModule(item.type as ModuleType)}>
                                    <div className={`absolute inset-0 bg-gradient-to-br ${item.bg} rounded-2xl transform ${item.rotate} group-hover:rotate-6 transition-transform duration-300 opacity-20`}></div>
                                    <div className={`relative bg-gradient-to-br ${item.bg} rounded-2xl p-6 cursor-pointer transform group-hover:scale-105 group-hover:-translate-y-2 transition-all duration-300 shadow-lg group-hover:shadow-2xl`}>
                                        <div className="text-center text-white">
                                            <div className="text-5xl mb-3 transform group-hover:scale-110 transition-transform duration-300">{item.icon}</div>
                                            <h3 className="font-bold text-lg mb-1">{item.title}</h3>
                                            <p className="text-sm opacity-90">{item.subtitle}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                             <div className="group relative" onClick={() => openModule('statistics')}>
                                <div className="absolute inset-0 bg-gradient-to-br from-gray-400 to-gray-600 rounded-2xl transform -rotate-1 group-hover:-rotate-2 transition-transform duration-300 opacity-20"></div>
                                {/* FIX: Replaced a backtick with a double quote to fix a syntax error in the className property. This was causing cascading parsing errors. */}
                                <div className="relative bg-gradient-to-br from-gray-400 to-gray-600 rounded-2xl p-6 cursor-pointer transform group-hover:scale-105 group-hover:-translate-y-2 transition-all duration-300 shadow-lg group-hover:shadow-2xl">
                                    <div className="text-center text-white">
                                        <div className="text-5xl mb-3 transform group-hover:scale-110 transition-transform duration-300">📊</div>
                                        <h3 className="font-bold text-lg mb-1">Thống kê</h3>
                                        <p className="text-sm opacity-90">Dữ liệu</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">📊 Hoạt động gần đây</h2>
                <div className="space-y-3">
                    {recentActivities.length > 0 ? (
                        recentActivities.map(activity => (
                            <div key={activity.id} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                                <div className="flex items-center space-x-3">
                                    <div className="text-2xl">{getActivityIcon(activity.type)}</div>
                                    <div>
                                        <p className="text-sm font-medium text-gray-800">{activity.content || `${activity.userName} đã đăng nhập.`}</p>
                                        <p className="text-xs text-gray-500">{new Date(activity.timestamp).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</p>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="text-gray-500 text-center py-8">Chưa có hoạt động nào. Hãy bắt đầu khám phá các module!</div>
                    )}
                </div>
            </div>
        </div>
    );
};
