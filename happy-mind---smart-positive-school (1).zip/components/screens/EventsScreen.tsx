
import React, { useState, useRef } from 'react';

interface EventsScreenProps {
    addToast: (message: string) => void;
    studentLogins: string[];
}

export const EventsScreen: React.FC<EventsScreenProps> = ({ addToast, studentLogins }) => {
    const [hasVoted, setHasVoted] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const sharePhoto = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            addToast("Ảnh của bạn đã được chia sẻ thành công! 📸");
        }
    };

    const voteStudent = (studentName: string) => {
        if (!hasVoted) {
            setHasVoted(true);
            addToast(`Đã ghi nhận lượt bình chọn cho ${studentName}! 🏅`);
        }
    };
    
    // Combine default and logged-in students, ensuring uniqueness
    const defaultStudents = ["Nguyễn Văn An", "Trần Thị Bích"]; // Example default
    const allStudents = [...new Set([...defaultStudents, ...studentLogins])];

    return (
        <div id="events-screen" className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">🌈 Happy Learning Week</h2>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
                     <div className="bg-gradient-to-br from-red-400 to-pink-500 text-white p-4 rounded-lg text-center"><h3 className="font-bold">Thứ Hai</h3><div className="text-2xl my-2">🎯</div><p className="text-sm">Ngày thử thách</p></div>
                     <div className="bg-gradient-to-br from-orange-400 to-yellow-500 text-white p-4 rounded-lg text-center"><h3 className="font-bold">Thứ Ba</h3><div className="text-2xl my-2">🎨</div><p className="text-sm">Ngày sáng tạo</p></div>
                     <div className="bg-gradient-to-br from-green-400 to-blue-500 text-white p-4 rounded-lg text-center"><h3 className="font-bold">Thứ Tư</h3><div className="text-2xl my-2">🤝</div><p className="text-sm">Ngày chia sẻ</p></div>
                     <div className="bg-gradient-to-br from-blue-400 to-purple-500 text-white p-4 rounded-lg text-center"><h3 className="font-bold">Thứ Năm</h3><div className="text-2xl my-2">🏆</div><p className="text-sm">Ngày thi đấu</p></div>
                     <div className="bg-gradient-to-br from-purple-400 to-pink-500 text-white p-4 rounded-lg text-center"><h3 className="font-bold">Thứ Sáu</h3><div className="text-2xl my-2">🎉</div><p className="text-sm">Ngày tổng kết</p></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div className="bg-gradient-to-br from-yellow-400 to-orange-500 text-white p-6 rounded-lg">
                        <h3 className="text-lg font-bold mb-4">📸 Chia sẻ ảnh hoạt động</h3>
                        <p className="text-sm mb-4">Tải lên và chia sẻ những khoảnh khắc đẹp trong tuần học tập.</p>
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
                        <button onClick={sharePhoto} className="bg-white text-orange-600 px-4 py-2 rounded font-semibold hover:bg-gray-100 transition-colors">Chia sẻ ảnh</button>
                    </div>
                     <div className="bg-gradient-to-br from-pink-400 to-red-500 text-white p-6 rounded-lg">
                        <h3 className="text-lg font-bold mb-4">🏅 Bình chọn học sinh truyền cảm hứng</h3>
                        <p className="text-sm mb-2">Bình chọn bạn học sinh tích cực nhất tuần này.</p>
                        <div className="max-h-40 overflow-y-auto space-y-2 pr-2">
                             {allStudents.length > 0 ? (
                                allStudents.map(student => (
                                    <div key={student} className="flex items-center justify-between bg-white/20 p-2 rounded">
                                        <span className="text-sm font-medium">{student}</span>
                                        <button 
                                            onClick={() => voteStudent(student)}
                                            disabled={hasVoted}
                                            className="bg-white text-red-600 px-3 py-1 rounded text-xs font-semibold hover:bg-gray-100 disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors"
                                        >
                                            {hasVoted ? 'Đã' : 'Bình chọn'}
                                        </button>
                                    </div>
                                ))
                            ) : (
                                <p className="text-xs text-white/80">Chưa có học sinh nào đăng nhập để bình chọn.</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};