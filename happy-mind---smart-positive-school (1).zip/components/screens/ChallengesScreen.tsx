
import React, { useState } from 'react';
import { AppDataItem } from '../../types';

interface ChallengesScreenProps {
    recordActivity: (type: AppDataItem['type'], content: string) => void;
    addToast: (message: string) => void;
}

const challenges = [
    "Nếu một hình vuông có chu vi 20cm, diện tích của nó là bao nhiêu?",
    "Tìm từ đồng nghĩa của 'hạnh phúc'",
    "What is the past tense of 'go'?",
    "Hãy kể về một kỷ niệm đẹp của bạn"
];

export const ChallengesScreen: React.FC<ChallengesScreenProps> = ({ recordActivity, addToast }) => {
    const [dailyChallenge, setDailyChallenge] = useState(challenges[0]);

    const startDailyChallenge = () => {
        const randomChallenge = challenges[Math.floor(Math.random() * challenges.length)];
        setDailyChallenge(randomChallenge);
        addToast("Thử thách mới đã được tạo! 🎯");
        recordActivity('mission', 'Bắt đầu thử thách học tập mới');
    };

    return (
        <div id="challenges-screen">
            <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">🎯 Thử thách học tập</h2>
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg p-6 mb-6">
                    <h3 className="text-xl font-bold mb-2">Thử thách hôm nay</h3>
                    <p className="mb-4">{dailyChallenge}</p>
                    <button onClick={startDailyChallenge} className="bg-white text-purple-600 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-colors">Bắt đầu thử thách</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-6 rounded-lg text-white">
                        <h3 className="text-lg font-bold mb-4">🏆 Tủ thành tích cá nhân</h3>
                        <div className="grid grid-cols-4 gap-2">
                            <div className="bg-white bg-opacity-20 rounded-lg p-2 text-center"><div className="text-2xl">🥇</div><div className="text-xs">Toán</div></div>
                            <div className="bg-white bg-opacity-20 rounded-lg p-2 text-center"><div className="text-2xl">🥈</div><div className="text-xs">Văn</div></div>
                            <div className="bg-white bg-opacity-20 rounded-lg p-2 text-center"><div className="text-2xl">🥉</div><div className="text-xs">Anh</div></div>
                            <div className="bg-white bg-opacity-20 rounded-lg p-2 text-center"><div className="text-2xl">🏅</div><div className="text-xs">Cảm xúc</div></div>
                        </div>
                    </div>
                    <div className="bg-gradient-to-br from-green-400 to-blue-500 p-6 rounded-lg text-white">
                        <h3 className="text-lg font-bold mb-4">📈 Thống kê</h3>
                        <div className="space-y-2">
                            <div className="flex justify-between"><span>Thử thách hoàn thành:</span> <span className="font-bold">47/50</span></div>
                            <div className="flex justify-between"><span>Streak hiện tại:</span> <span className="font-bold">12 ngày</span></div>
                            <div className="flex justify-between"><span>Điểm trung bình:</span> <span className="font-bold">8.5/10</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};