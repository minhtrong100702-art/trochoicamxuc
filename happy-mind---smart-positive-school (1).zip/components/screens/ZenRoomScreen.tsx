
import React from 'react';

interface ZenRoomScreenProps {
    addToast: (message: string) => void;
}

export const ZenRoomScreen: React.FC<ZenRoomScreenProps> = ({ addToast }) => {
    
    const enterZenArea = (area: string) => {
        addToast(`Đang vào ${area}! 🧘`);
    };

    const sendZenMessage = () => {
        addToast("Đã gửi lời chúc! 💌");
    };

    return (
        <div id="zen-room-screen">
            <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">🧘 Phòng thư giãn ảo - ZenRoom</h2>
                <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg p-8 mb-6 relative min-h-[400px]">
                    <h3 className="text-center text-lg font-semibold mb-6">Bản đồ phòng thư giãn</h3>
                    <div className="grid grid-cols-2 gap-8 h-full">
                        <div className="bg-green-200 rounded-lg p-4 cursor-pointer hover:bg-green-300 transition-colors card-hover" onClick={() => enterZenArea('breathing')}>
                            <div className="text-center"><div className="text-4xl mb-2">🌿</div><h4 className="font-semibold">Khu hít thở &amp; thiền</h4><p className="text-sm text-gray-600">3 phút thư giãn</p></div>
                        </div>
                        <div className="bg-blue-200 rounded-lg p-4 cursor-pointer hover:bg-blue-300 transition-colors card-hover" onClick={() => enterZenArea('music')}>
                            <div className="text-center"><div className="text-4xl mb-2">🎵</div><h4 className="font-semibold">Khu âm nhạc học đường</h4><p className="text-sm text-gray-600">Nhạc thư giãn</p></div>
                        </div>
                        <div className="bg-yellow-200 rounded-lg p-4 cursor-pointer hover:bg-yellow-300 transition-colors card-hover" onClick={() => enterZenArea('inspiration')}>
                            <div className="text-center"><div className="text-4xl mb-2">💡</div><h4 className="font-semibold">Góc cảm hứng</h4><p className="text-sm text-gray-600">Câu chuyện động lực</p></div>
                        </div>
                        <div className="bg-pink-200 rounded-lg p-4 cursor-pointer hover:bg-pink-300 transition-colors card-hover" onClick={() => enterZenArea('creative')}>
                            <div className="text-center"><div className="text-4xl mb-2">🎨</div><h4 className="font-semibold">Khu sáng tạo học sinh</h4><p className="text-sm text-gray-600">Chia sẻ tác phẩm</p></div>
                        </div>
                    </div>
                </div>
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-6">
                    <h3 className="text-lg font-semibold mb-4">💌 Gửi lời chúc tích cực</h3>
                    <div className="flex gap-4">
                        <input type="text" id="zen-message" placeholder="Viết lời chúc tích cực cho bạn bè..." className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" />
                        <button onClick={sendZenMessage} className="bg-purple-500 text-white px-6 py-2 rounded-lg hover:bg-purple-600 transition-colors">Gửi</button>
                    </div>
                </div>
            </div>
        </div>
    );
};