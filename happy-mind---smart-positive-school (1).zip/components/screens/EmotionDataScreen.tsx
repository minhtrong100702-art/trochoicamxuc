
import React, { useMemo } from 'react';
import { AppDataItem, Emotion } from '../../types';

interface EmotionDataScreenProps {
    appData: AppDataItem[];
}

const emotionDisplayData: { emotion: Emotion; label: string; icon: string; color: string; colorHex: string; }[] = [
    { emotion: 'very-happy', label: 'Rất vui', icon: '😄', color: 'bg-green-500', colorHex: '#22c55e' },
    { emotion: 'happy', label: 'Vui', icon: '😊', color: 'bg-blue-500', colorHex: '#3b82f6' },
    { emotion: 'neutral', label: 'Bình thường', icon: '😐', color: 'bg-yellow-500', colorHex: '#eab308' },
    { emotion: 'sad', label: 'Buồn', icon: '😔', color: 'bg-orange-500', colorHex: '#f97316' },
    { emotion: 'stressed', label: 'Căng thẳng', icon: '😰', color: 'bg-red-500', colorHex: '#ef4444' }
];

const PieChart: React.FC<{ data: { label: string, value: number, color: string }[] }> = ({ data }) => {
    const total = data.reduce((sum, item) => sum + item.value, 0);
    if (total === 0) return <div className="w-48 h-48 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 text-center p-4">Chưa có dữ liệu cảm xúc</div>;

    let cumulative = 0;
    const gradientParts = data.map(item => {
        const percentage = (item.value / total) * 100;
        const part = `${item.color} ${cumulative}% ${cumulative + percentage}%`;
        cumulative += percentage;
        return part;
    });

    return (
        <div className="w-48 h-48 rounded-full shadow-lg" style={{ background: `conic-gradient(${gradientParts.join(', ')})` }}></div>
    );
};

export const EmotionDataScreen: React.FC<EmotionDataScreenProps> = ({ appData }) => {
    const emotionStats = useMemo(() => {
        const emotionRecords = appData.filter(item => item.type === 'emotion_record' && item.emotion);
        const emotionCounts: Record<Emotion, number> = {
            'very-happy': 0,
            'happy': 0,
            'neutral': 0,
            'sad': 0,
            'stressed': 0,
        };
        const studentEmotions: { [key: string]: Emotion[] } = {};

        emotionRecords.forEach(record => {
            if (record.emotion) {
                emotionCounts[record.emotion]++;
                if (!studentEmotions[record.userName]) {
                    studentEmotions[record.userName] = [];
                }
                studentEmotions[record.userName].push(record.emotion);
            }
        });

        const totalEmotions = emotionRecords.length;
        const uniqueStudents = Object.keys(studentEmotions).length;
        const positiveEmotions = emotionCounts['very-happy'] + emotionCounts['happy'];
        const positiveRate = totalEmotions > 0 ? Math.round((positiveEmotions / totalEmotions) * 100) : 0;

        return { emotionRecords, emotionCounts, totalEmotions, uniqueStudents, positiveRate };
    }, [appData]);

    const emotionChartData = emotionDisplayData.map(e => ({
        label: e.label,
        value: emotionStats.emotionCounts[e.emotion],
        color: e.colorHex
    }));

    const recentEmotionRecords = [...emotionStats.emotionRecords]
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 10);

    return (
        <div id="emotion-data-screen" className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">📊 Dữ liệu cảm xúc lớp học</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 text-center">
                    <div className="bg-gradient-to-br from-blue-100 to-blue-200 p-4 rounded-xl shadow-sm">
                        <p className="text-3xl font-bold text-blue-800">{emotionStats.totalEmotions}</p>
                        <p className="text-sm font-semibold text-blue-700">Tổng lượt ghi nhận</p>
                    </div>
                    <div className="bg-gradient-to-br from-purple-100 to-purple-200 p-4 rounded-xl shadow-sm">
                        <p className="text-3xl font-bold text-purple-800">{emotionStats.uniqueStudents}</p>
                        <p className="text-sm font-semibold text-purple-700">Học sinh tham gia</p>
                    </div>
                    <div className="bg-gradient-to-br from-green-100 to-green-200 p-4 rounded-xl shadow-sm">
                        <p className="text-3xl font-bold text-green-800">{emotionStats.positiveRate}%</p>
                        <p className="text-sm font-semibold text-green-700">Tỷ lệ tích cực</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                    <div className="bg-gray-50 p-6 rounded-lg">
                        <h3 className="font-bold text-gray-700 mb-4 text-center text-lg">Phân bổ cảm xúc</h3>
                        <div className="flex items-center justify-center gap-8">
                            <PieChart data={emotionChartData} />
                            <div className="text-sm space-y-2">
                                {emotionDisplayData.map(e => (
                                    <div key={e.emotion} className="flex items-center gap-2">
                                        <div className={`w-4 h-4 rounded-full ${e.color}`}></div>
                                        <span>{e.label} ({emotionStats.emotionCounts[e.emotion]})</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                    
                    <div className="bg-gray-50 p-6 rounded-lg">
                        <h3 className="font-bold text-gray-700 mb-4 text-center text-lg">Thống kê chi tiết</h3>
                        <div className="space-y-3">
                            {emotionDisplayData.map(e => {
                                const count = emotionStats.emotionCounts[e.emotion];
                                const percentage = emotionStats.totalEmotions > 0 ? Math.round((count / emotionStats.totalEmotions) * 100) : 0;
                                return (
                                    <div key={e.emotion}>
                                        <div className="flex justify-between items-center text-sm mb-1">
                                            <span className="font-semibold">{e.icon} {e.label}</span>
                                            <span className="text-gray-600">{count} ({percentage}%)</span>
                                        </div>
                                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                                            <div className={`${e.color} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">📝 Nhật ký cảm xúc gần đây</h2>
                <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {recentEmotionRecords.length > 0 ? (
                        recentEmotionRecords.map(record => {
                            const displayInfo = emotionDisplayData.find(e => e.emotion === record.emotion);
                            return (
                                <div key={record.id} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                                    <div className="flex items-center space-x-3">
                                        <div className="text-2xl">{displayInfo?.icon || '🤔'}</div>
                                        <div>
                                            <p className="text-sm font-medium text-gray-800">
                                                <span className="font-bold">{record.userName}</span> cảm thấy {displayInfo?.label.toLowerCase() || 'không rõ'}.
                                            </p>
                                            <p className="text-xs text-gray-500">
                                                {new Date(record.timestamp).toLocaleString('vi-VN', {
                                                    hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric'
                                                })}
                                            </p>
                                        </div>
                                    </div>
                                    <div className={`px-3 py-1 text-xs font-semibold text-white ${displayInfo?.color || 'bg-gray-400'} rounded-full`}>
                                        {displayInfo?.label || 'N/A'}
                                    </div>
                                </div>
                            );
                        })
                    ) : (
                        <div className="text-gray-500 text-center py-8">Chưa có ai ghi nhận cảm xúc. Hãy là người đầu tiên!</div>
                    )}
                </div>
            </div>
        </div>
    );
};