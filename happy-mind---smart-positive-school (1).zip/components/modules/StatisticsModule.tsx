
import React, { useMemo, useState } from 'react';
import { AppDataItem, Emotion } from '../../types';
import { GoogleGenAI } from '@google/genai';

interface StatisticsModuleProps {
    onClose: () => void;
    appData: AppDataItem[];
    userName: string;
    addToast: (message: string) => void;
}

const emotionDisplayData: { emotion: Emotion; label: string; icon: string; color: string; colorHex: string; }[] = [
    { emotion: 'very-happy', label: 'Rất vui', icon: '😄', color: 'bg-green-500', colorHex: '#22c55e' },
    { emotion: 'happy', label: 'Vui', icon: '😊', color: 'bg-blue-500', colorHex: '#3b82f6' },
    { emotion: 'neutral', label: 'Bình thường', icon: '😐', color: 'bg-yellow-500', colorHex: '#eab308' },
    { emotion: 'sad', label: 'Buồn', icon: '😔', color: 'bg-orange-500', colorHex: '#f97316' },
    { emotion: 'stressed', label: 'Căng thẳng', icon: '😰', color: 'bg-red-500', colorHex: '#ef4444' }
];

const activityTypes: { type: AppDataItem['type'], label: string, icon: string }[] = [
    { type: 'zen-room', label: 'Phòng Zen', icon: '🧘' },
    { type: 'mission', label: 'Thử thách', icon: '🎯' },
    { type: 'smart-break', label: 'Trò chơi', icon: '🎮' },
    { type: 'happy-week', label: 'Sự kiện', icon: '🌈' },
];

const PieChart: React.FC<{ data: { label: string, value: number, color: string }[] }> = ({ data }) => {
    const total = data.reduce((sum, item) => sum + item.value, 0);
    if (total === 0) return <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 text-sm">No Data</div>;

    let cumulative = 0;
    const gradientParts = data.map(item => {
        const percentage = (item.value / total) * 100;
        const part = `${item.color} ${cumulative}% ${cumulative + percentage}%`;
        cumulative += percentage;
        return part;
    });

    return (
        <div className="w-32 h-32 rounded-full" style={{ background: `conic-gradient(${gradientParts.join(', ')})` }}></div>
    );
};

export const StatisticsModule: React.FC<StatisticsModuleProps> = ({ onClose, appData, userName, addToast }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [analysisResult, setAnalysisResult] = useState<{ summary: string; advice: string } | null>(null);

    const stats = useMemo(() => {
        // Fix: Use JSON.parse instead of parseInt to correctly parse the stats object from localStorage.
        const missionBadges = JSON.parse(localStorage.getItem('mission5Stats') || '{"badges":0}')?.badges || 0;
        const totalActivities = appData.length;

        const emotionCounts: Record<Emotion, number> = { 'very-happy': 0, 'happy': 0, 'neutral': 0, 'sad': 0, 'stressed': 0 };
        const emotionRecords = appData.filter(d => d.type === 'emotion_record');
        emotionRecords.forEach(record => {
            if (record.emotion) emotionCounts[record.emotion]++;
        });
        const totalEmotions = emotionRecords.length;
        const positiveEmotions = emotionCounts['very-happy'] + emotionCounts['happy'];
        const positiveRate = totalEmotions > 0 ? Math.round((positiveEmotions / totalEmotions) * 100) : 0;

        const activityCounts: Record<string, number> = {
            'zen-room': appData.filter(d => d.type === 'zen-room').length,
            'mission': appData.filter(d => d.type === 'mission').length,
            'smart-break': appData.filter(d => d.type === 'smart-break').length,
            'happy-week': appData.filter(d => d.type === 'happy-week').length,
        };
        
        return { missionBadges, totalActivities, positiveRate, emotionCounts, totalEmotions, activityCounts };
    }, [appData]);

    const handleAnalysisClick = async () => {
        setIsLoading(true);
        setAnalysisResult(null);

        const dataForAnalysis = {
            total_activities: stats.totalActivities,
            positive_emotion_rate: `${stats.positiveRate}%`,
            emotion_distribution: stats.emotionCounts,
            favorite_activity_type: Object.keys(stats.activityCounts).reduce((a, b) => stats.activityCounts[a] > stats.activityCounts[b] ? a : b, 'none'),
        };
        
        const prompt = `Bạn là một chuyên gia tâm lý học đường thân thiện và sâu sắc. Dựa vào dữ liệu hoạt động của học sinh tên "${userName}" sau đây, hãy đưa ra một phân tích ngắn gọn và một lời khuyên tích cực.
        
        Dữ liệu: ${JSON.stringify(dataForAnalysis)}

        Yêu cầu:
        1. Phân tích: Đưa ra một nhận xét ngắn (2-3 câu) về trạng thái cảm xúc và xu hướng hoạt động của học sinh.
        2. Lời khuyên: Đưa ra một lời khuyên cụ thể, mang tính xây dựng và động viên (1-2 câu).
        
        Hãy trả lời bằng tiếng Việt và giữ giọng văn thật gần gũi, ấm áp. Trả lời dưới dạng JSON với hai key: "summary" và "advice".`;

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: "application/json",
                }
            });
            const text = response.text.trim();
            const result = JSON.parse(text);
            setAnalysisResult(result);
        } catch (error) {
            console.error("Gemini API call failed:", error);
            addToast("Rất tiếc, không thể phân tích ngay lúc này.");
        } finally {
            setIsLoading(false);
        }
    };

    const emotionChartData = emotionDisplayData.map(e => ({
        label: e.label,
        value: stats.emotionCounts[e.emotion],
        color: e.colorHex
    }));

    return (
        <div className="p-4 md:p-6 max-w-3xl mx-auto">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl md:text-2xl font-bold text-gray-800">📊 Bảng điều khiển của {userName}</h2>
                <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-xl md:text-2xl">&times;</button>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 p-4 rounded-xl shadow-sm text-center">
                    <div className="text-4xl">🚀</div>
                    <p className="text-3xl font-bold text-blue-800">{stats.totalActivities}</p>
                    <p className="text-sm font-semibold text-blue-700">Tổng hoạt động</p>
                </div>
                <div className="bg-gradient-to-br from-yellow-100 to-yellow-200 p-4 rounded-xl shadow-sm text-center">
                    <div className="text-4xl">🏆</div>
                    <p className="text-3xl font-bold text-yellow-800">{stats.missionBadges}</p>
                    <p className="text-sm font-semibold text-yellow-700">Huy hiệu Mission 5'</p>
                </div>
                <div className="bg-gradient-to-br from-green-100 to-green-200 p-4 rounded-xl shadow-sm text-center">
                    <div className="text-4xl">😊</div>
                    <p className="text-3xl font-bold text-green-800">{stats.positiveRate}%</p>
                    <p className="text-sm font-semibold text-green-700">Cảm xúc tích cực</p>
                </div>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="bg-white p-4 rounded-xl shadow-sm">
                    <h3 className="font-bold text-gray-700 mb-4 text-center">Biểu đồ Cảm xúc</h3>
                    <div className="flex items-center justify-center gap-6">
                        <PieChart data={emotionChartData} />
                        <div className="text-xs space-y-1">
                            {emotionDisplayData.map(e => (
                                <div key={e.emotion} className="flex items-center gap-2">
                                    <div className={`w-3 h-3 rounded-full ${e.color}`}></div>
                                    <span>{e.label}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
                <div className="bg-white p-4 rounded-xl shadow-sm">
                    <h3 className="font-bold text-gray-700 mb-4 text-center">Hoạt động Yêu thích</h3>
                    <div className="space-y-3">
                        {activityTypes.map(act => {
                            const count = stats.activityCounts[act.type] || 0;
                            const maxCount = Math.max(...Object.values(stats.activityCounts), 1);
                            const percentage = (count / maxCount) * 100;
                            return (
                                <div key={act.type}>
                                    <div className="flex justify-between items-center text-sm mb-1">
                                        <span className="font-semibold">{act.icon} {act.label}</span>
                                        <span className="text-gray-600">{count} lần</span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                                        <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: `${percentage}%` }}></div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
            
            {/* AI Analysis */}
            <div className="bg-gradient-to-r from-purple-50 to-indigo-100 p-6 rounded-xl shadow-sm">
                 <h3 className="font-bold text-gray-800 mb-4 text-center text-lg">Phân tích Cảm xúc cùng Gemini</h3>
                 <div className="text-center mb-4">
                     <button onClick={handleAnalysisClick} disabled={isLoading} className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold py-3 px-6 rounded-full hover:scale-105 transition-transform disabled:opacity-50 disabled:cursor-wait">
                         {isLoading ? 'Đang phân tích...' : '🤖 Bắt đầu phân tích'}
                     </button>
                 </div>
                 {isLoading && (
                     <div className="text-center text-purple-700">
                         <p>Gemini đang phân tích dữ liệu của bạn, vui lòng đợi trong giây lát...</p>
                     </div>
                 )}
                 {analysisResult && (
                     <div className="mt-4 bg-white/50 p-4 rounded-lg space-y-3 text-sm">
                         <div>
                             <h4 className="font-bold text-purple-800 flex items-center gap-2"><span className="text-xl">🧠</span> Phân tích chung:</h4>
                             <p className="text-gray-700">{analysisResult.summary}</p>
                         </div>
                         <div>
                            <h4 className="font-bold text-green-800 flex items-center gap-2"><span className="text-xl">💡</span> Lời khuyên dành cho bạn:</h4>
                             <p className="text-gray-700">{analysisResult.advice}</p>
                         </div>
                     </div>
                 )}
            </div>
        </div>
    );
};