
import React, { useState } from 'react';
import { ModuleType } from '../../types';

interface HappyWeekModuleProps {
    onClose: () => void;
    addToast: (message: string) => void;
    openModule: (moduleType: ModuleType) => void;
}

const students = ["Nguyễn Văn An", "Trần Thị Bích", "Lê Minh Cường"];

export const HappyWeekModule: React.FC<HappyWeekModuleProps> = ({ onClose, addToast, openModule }) => {
    const [joyText, setJoyText] = useState('');
    const [thanksText, setThanksText] = useState('');
    const [hasVoted, setHasVoted] = useState(false);
    
    const dayOfWeek = new Date().getDay(); // Sunday - 0, Monday - 1, ...
    
    const activities = [
        { day: 'Thứ Hai', title: 'Lễ phát động', description: 'Ký Thẻ cam kết học đường số để bắt đầu tuần lễ.', dayIndex: 1, action: () => addToast('Bạn đã ký cam kết thành công! 👍'), actionLabel: 'Ký cam kết' },
        { day: 'Thứ Ba', title: '1 ngày không than mệt', description: 'Chia sẻ một điều khiến bạn cảm thấy vui trong ngày hôm nay.', dayIndex: 2, input: joyText, setInput: setJoyText, action: () => { if(joyText.trim()){addToast('Cảm ơn bạn đã chia sẻ niềm vui! 😊'); setJoyText('');} else {addToast('Hãy viết điều gì đó nhé!');} }, actionLabel: 'Chia sẻ' },
        { day: 'Thứ Tư', title: 'Thiền 3 phút', description: 'Dành 3 phút để tĩnh tâm và kết nối với bản thân trong ZenRoom.', dayIndex: 3, action: () => { onClose(); openModule('zen-room'); }, actionLabel: 'Bắt đầu thiền' },
        { day: 'Thứ Năm', title: 'Hộp thư ảo', description: 'Gửi một lời cảm ơn chân thành đến thầy cô hoặc bạn bè.', dayIndex: 4, input: thanksText, setInput: setThanksText, action: () => { if(thanksText.trim()){addToast('Lời cảm ơn của bạn đã được gửi đi! 💌'); setThanksText('');} else {addToast('Hãy viết lời cảm ơn nhé!');} }, actionLabel: 'Gửi' },
        { day: 'Thứ Sáu', title: 'Triển lãm Khoảnh khắc hạnh phúc', description: 'Xem lại những khoảnh khắc đẹp của cả lớp trên Padlet.', dayIndex: 5, action: () => { window.open('https://padlet.com/', '_blank'); addToast('Đang mở triển lãm...'); }, actionLabel: 'Xem triển lãm' },
    ];

    const handleVote = (student: string) => {
        if (!hasVoted) {
            setHasVoted(true);
            addToast(`Bạn đã bình chọn cho ${student}! 🏅`);
        }
    };

    return (
        <div className="p-4 md:p-6">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg md:text-2xl font-bold text-gray-800">🌈 Tuần học hạnh phúc</h2>
                <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-xl md:text-2xl">&times;</button>
            </div>

            <div className="space-y-4 mb-6">
                {activities.map((activity, index) => (
                    <div key={index} className={`bg-white p-4 rounded-lg shadow-sm border-l-4 ${dayOfWeek === activity.dayIndex ? 'border-purple-500 bg-purple-50' : 'border-gray-200'}`}>
                        <div className="flex items-start justify-between">
                            <div>
                                <p className="font-bold text-purple-700">{activity.day}: <span className="text-gray-800">{activity.title}</span></p>
                                <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
                            </div>
                        </div>
                        <div className="mt-3 flex gap-2">
                             {activity.input !== undefined && (
                                <input 
                                    type="text"
                                    value={activity.input}
                                    onChange={(e) => activity.setInput && activity.setInput(e.target.value)}
                                    placeholder="Viết ở đây..."
                                    className="flex-grow px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-purple-500"
                                />
                            )}
                            <button onClick={activity.action} className="bg-purple-500 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-purple-600 transition-colors whitespace-nowrap">{activity.actionLabel}</button>
                        </div>
                    </div>
                ))}
            </div>

             <div className="bg-white p-4 rounded-lg shadow-sm border-l-4 border-yellow-400 mb-6">
                <h3 className="font-bold text-yellow-800 mb-3">🏅 Bình chọn Học sinh truyền cảm hứng</h3>
                <div className="space-y-2">
                    {students.map(student => (
                        <div key={student} className="flex items-center justify-between">
                            <span className="text-sm">{student}</span>
                            <button onClick={() => handleVote(student)} disabled={hasVoted} className={`px-3 py-1 text-xs rounded ${hasVoted ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-yellow-500 hover:bg-yellow-600 text-white'}`}>
                                {hasVoted ? 'Đã bình chọn' : 'Bình chọn'}
                            </button>
                        </div>
                    ))}
                </div>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4 text-center">
                <p className="font-semibold text-sm text-gray-700 italic">“Giảm áp lực học tập không phải là học ít hơn, mà là học thông minh hơn, hiểu mình hơn và hạnh phúc hơn trong từng giờ học.”</p>
            </div>
        </div>
    );
};