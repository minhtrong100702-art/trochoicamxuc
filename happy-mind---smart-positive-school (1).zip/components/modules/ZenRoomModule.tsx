
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AppDataItem } from '../../types';
import { audioService } from '../../services/audioService';

interface ZenRoomModuleProps {
    onClose: () => void;
    recordActivity: (type: AppDataItem['type'], content: string) => void;
    addToast: (message: string) => void;
    updateHappyPoints: () => void;
}

// --- Story Data ---
const inspirationalStories = [
    {
        id: 1,
        title: "Hạt giống nhỏ",
        emoji: "🌱",
        content: `Có một hạt giống nhỏ bé nằm trong lòng đất tối tăm. Nó cảm thấy cô đơn và sợ hãi.\n\n"Tại sao mình phải ở đây?" - hạt giống thắc mắc.\n\nMột ngày, những giọt mưa nhẹ nhàng rơi xuống. Hạt giống bắt đầu nứt vỏ. Nó sợ hãi vì nghĩ mình đang bị phá hủy.\n\nNhưng từ vết nứt ấy, một chồi xanh nhỏ bé đã nhú lên. Ngày qua ngày, với ánh nắng và nước mưa, chồi non ấy lớn lên thành cây cao vượt khỏi mặt đất.\n\n"Ah!" - cây nhỏ thốt lên khi nhìn thấy thế giới rộng lớn - "Hoá ra những khó khăn ban đầu chính là để giúp mình lớn mạnh!"`,
        lesson: `Những thử thách trong học tập giống như cơn mưa và bóng tối - chúng giúp chúng ta phát triển và trở nên mạnh mẽ hơn. Đừng sợ hãi khó khăn, hãy tin rằng chúng sẽ giúp bạn "nảy mầm" thành phiên bản tốt nhất của chính mình!`
    },
    {
        id: 2,
        title: "Con bướm và kén",
        emoji: "🦋",
        content: `Một chú sâu bướm nhỏ đang sống trong chiếc kén chật hẹp. Nó cảm thấy khó chịu và muốn thoát ra.\n\n"Tại sao mình phải bị nhốt trong này?" - chú sâu nghĩ.\n\nMột cậu bé thấy chú sâu đang vật lộn để thoát khỏi kén, liền dùng kéo cắt kén để giúp. Chú sâu thoát ra dễ dàng, nhưng đôi cánh của nó yếu ớt và không thể bay được.\n\nÔng giáo viên giải thích: "Quá trình vật lộn thoát khỏi kén chính là cách để cánh bướm trở nên mạnh mẽ. Khi ta giúp quá nhiều, ta đã tước đi cơ hội phát triển của nó."`,
        lesson: `Những bài tập khó, những lần phải suy nghĩ vất vả chính là "chiếc kén" giúp trí não của chúng ta mạnh mẽ hơn. Đừng tìm cách "thoát" khỏi khó khăn, hãy vượt qua chúng để có đôi cánh tri thức vững chắc!`
    },
    {
        id: 3,
        title: "Ngôi sao biển",
        emoji: "⭐",
        content: `Sau cơn bão lớn, hàng nghìn ngôi sao biển bị dạt vào bờ. Chúng sẽ chết nếu không được trả về biển kịp thời.\n\nMột cậu bé đang nhặt từng con một ném về biển. Một người đàn ông đi qua nói: "Cậu bé, có hàng nghìn con ở đây, cậu không thể cứu hết được đâu. Việc làm của cậu chẳng có ý nghĩa gì!"\n\nCậu bé nhặt một ngôi sao biển khác, ném về phía biển và nói: "Nhưng với con này, việc làm của em có ý nghĩa lắm!"`,
        lesson: `Đừng nghĩ rằng những việc nhỏ bé mình làm không quan trọng. Mỗi bài tập hoàn thành, mỗi lần giúp đỡ bạn bè, mỗi hành động tích cực đều tạo nên sự khác biệt. Hãy bắt đầu từ những việc nhỏ - chúng sẽ tạo nên những thay đổi lớn!`
    },
    {
        id: 4,
        title: "Núi và sỏi đá",
        emoji: "🏔️",
        content: `Có một ngọn núi cao vút muốn trở nên hoàn hảo. Nó nhìn thấy những viên sỏi nhỏ lăn xuống từ sườn núi và cảm thấy khó chịu.\n\n"Tại sao mình cứ mất đi những mảnh nhỏ này?" - núi thắc mắc.\n\nNhiều năm trôi qua, những viên sỏi ấy được nước suối cuốn đi, mài mòn thành những viên đá cuội tròn trịa, đẹp đẽ. Chúng trở thành nền móng cho những con đường, làm đẹp cho những khu vườn.\n\nNgọn núi nhận ra: "Ah, những gì mình 'mất đi' thực ra đang giúp đỡ thế giới trở nên đẹ đẽ hơn!"`,
        lesson: `Đôi khi chúng ta phải "hy sinh" thời gian chơi để học bài, "mất đi" sự thoải mái để luyện tập. Nhưng những "mất mát" này thực ra đang giúp chúng ta xây dựng nền tảng vững chắc cho tương lai. Hãy kiên nhẫn với quá trình học tập!`
    },
    {
        id: 5,
        title: "Cầu vồng sau mưa",
        emoji: "🌈",
        content: `Một cô bé nhỏ rất sợ sấm sét. Mỗi khi trời mưa to, cô ấy lại trốn dưới chăn và khóc.\n\nBà ngoại nói: "Con ơi, hãy nhìn ra ngoài cửa sổ sau khi mưa tạnh."\n\nLần đầu tiên, cô bé dũng cảm nhìn ra ngoài sau cơn mưa. Cô thấy một cầu vồng tuyệt đẹp bắc qua bầu trời, với bảy sắc màu rực rỡ.\n\n"Bà ơi, sao đẹp quá!" - cô bé thốt lên.\n\nBà ngoại mỉm cười: "Con thấy không? Không có mưa bão thì làm sao có cầu vồng? Những khó khăn trong cuộc sống cũng vậy - chúng mang đến cho ta những điều tuyệt vời mà ta không ngờ tới."`,
        lesson: `Sau những bài kiểm tra khó, những lần thất bại, luôn có những bài học quý giá và cơ hội mới đang chờ đợi. Hãy kiên nhẫn vượt qua "cơn mưa" để được chiêm ngưỡng "cầu vồng" của thành công!`
    },
    // Adding a 6th story to match the menu
    {
        id: 6,
        title: "Dòng sông và tảng đá",
        emoji: "🏞️",
        content: `Có một dòng sông luôn chảy về phía trước. Trên đường đi, nó gặp một tảng đá lớn chắn ngang.\n\n"Tránh ra!" - dòng sông gầm lên.\n\nTảng đá im lặng. Dòng sông cố gắng xô đẩy nhưng tảng đá không hề di chuyển. Tức giận, dòng sông dùng hết sức mình để tấn công.\n\nNhiều năm trôi qua, dòng sông nhận ra rằng thay vì đối đầu, nó có thể nhẹ nhàng lượn quanh tảng đá. Dần dần, nước sông còn mài mòn tảng đá, tạo nên những hình thù đẹp đẽ. Dòng sông vẫn tiếp tục hành trình của mình, và tảng đá cũng trở thành một phần đặc biệt của dòng chảy.`,
        lesson: `Trong học tập, sẽ có những "tảng đá" kiến thức khó khăn. Thay vì nản lòng, hãy tìm cách tiếp cận chúng một cách linh hoạt và kiên trì. Mỗi ngày một chút, bạn sẽ vượt qua được và thậm chí biến khó khăn thành một phần sức mạnh của mình.`
    }
];


// --- Sub-components for each Zen Area ---

const MeditationPractice: React.FC<{ onBack: () => void; addToast: (msg: string) => void; updateHappyPoints: () => void; recordActivity: (type: any, content: string) => void; }> = ({ onBack, addToast, updateHappyPoints, recordActivity }) => {
    const [timeLeft, setTimeLeft] = useState(0);
    const [isActive, setIsActive] = useState(false);
    const [isBreathingIn, setIsBreathingIn] = useState(true);
    const timerRef = useRef<number | null>(null);
    const breathTimerRef = useRef<number | null>(null);

    const cleanupTimers = useCallback(() => {
        if (timerRef.current) clearInterval(timerRef.current);
        if (breathTimerRef.current) clearInterval(breathTimerRef.current);
    }, []);

    useEffect(() => {
        return cleanupTimers;
    }, [cleanupTimers]);

    const startSession = (minutes: number) => {
        cleanupTimers();
        const totalSeconds = minutes * 60;
        setTimeLeft(totalSeconds);
        setIsActive(true);
        setIsBreathingIn(true);
        addToast(`Bắt đầu thiền định ${minutes} phút! 🧘‍♀️`);
        recordActivity('zen-room', `Bắt đầu thiền định ${minutes} phút`);
        audioService.playSound('zen');

        timerRef.current = window.setInterval(() => {
            setTimeLeft(prev => {
                if (prev <= 1) {
                    cleanupTimers();
                    setIsActive(false);
                    addToast("🎉 Chúc mừng! Bạn đã hoàn thành phiên thiền định!");
                    updateHappyPoints();
                    audioService.playSound('success');
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);

        breathTimerRef.current = window.setInterval(() => {
            setIsBreathingIn(prev => !prev);
        }, 4000);
    };
    
    const stopSession = () => {
        cleanupTimers();
        setIsActive(false);
        addToast("Đã kết thúc phiên thiền định.");
        onBack();
    };


    if (isActive) {
        return (
             <div className="text-center w-full">
                 <div className="mb-4">
                     <div 
                         className="breathing-circle w-40 h-40 mx-auto bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg"
                         style={{ transform: `scale(${isBreathingIn ? 1.2 : 1})` }}
                     >
                         {isBreathingIn ? 'Hít vào' : 'Thở ra'}
                     </div>
                 </div>
                 <div className="text-4xl font-bold mb-2">{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60).toString().padStart(2, '0')}`}</div>
                 <div className="text-lg mb-4">Hãy tập trung vào hơi thở...</div>
                 <button onClick={stopSession} className="bg-red-500 text-white px-5 py-2 rounded-lg hover:bg-red-600">⏹️ Dừng</button>
             </div>
        );
    }

    return (
        <div className="text-center w-full max-w-lg mx-auto">
            <h3 className="text-xl font-semibold text-gray-700 mb-4">🧘‍♀️ Hướng dẫn thiền định cho học sinh</h3>

            <div className="space-y-4">
                 <div className="bg-white rounded-lg p-4 shadow-md">
                     <h4 className="font-semibold mb-3">🌸 Chọn thời gian thiền</h4>
                     <div className="grid grid-cols-3 gap-2">
                         <button onClick={() => startSession(3)} className="bg-green-500 text-white px-3 py-2 rounded text-sm hover:bg-green-600">3 phút</button>
                         <button onClick={() => startSession(5)} className="bg-blue-500 text-white px-3 py-2 rounded text-sm hover:bg-blue-600">5 phút</button>
                         <button onClick={() => startSession(10)} className="bg-purple-500 text-white px-3 py-2 rounded text-sm hover:bg-purple-600">10 phút</button>
                     </div>
                 </div>

                 <div className="bg-white rounded-lg p-4 shadow-md">
                     <h4 className="font-semibold mb-2">📚 Hướng dẫn thiền cơ bản</h4>
                     <div className="text-sm text-gray-700 space-y-2 text-left">
                         <div>1. 🪑 Ngồi thẳng lưng, thoải mái</div>
                         <div>2. 👁️ Nhắm mắt hoặc nhìn xuống dưới</div>
                         <div>3. 🫁 Thở sâu qua mũi, thở ra qua miệng</div>
                         <div>4. 🧠 Tập trung vào hơi thở</div>
                         <div>5. 💭 Khi có tạp niệm, nhẹ nhàng quay về hơi thở</div>
                     </div>
                 </div>
            </div>
            <button onClick={onBack} className="mt-6 text-sm text-gray-600 hover:text-gray-800">← Quay lại</button>
        </div>
    );
};


const MeditationBell: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    const [count, setCount] = useState(0);
    const [isAnimating, setIsAnimating] = useState(false);

    const handleBellClick = () => {
        setCount(c => c + 1);
        audioService.playBellSound(1);
        setIsAnimating(true);
        setTimeout(() => setIsAnimating(false), 200);
    };

    return (
        <div className="text-center w-full">
            <h3 className="text-xl font-semibold text-gray-700 mb-4">Cái mõ thiền</h3>
            <div
                className={`text-8xl mb-4 cursor-pointer transform transition-transform ${isAnimating ? 'scale-110 rotate-6' : 'scale-100'}`}
                onClick={handleBellClick}
            >
                🔔
            </div>
            <p className="text-lg font-semibold mb-6">Số lần gõ: <span className="text-purple-600">{count}</span></p>
            <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-800">← Quay lại</button>
        </div>
    );
};

const YouTubePlayer: React.FC<{ onBack: () => void }> = ({ onBack }) => (
    <div className="w-full text-center">
        <h3 className="text-lg font-semibold text-gray-700 mb-4">Nhạc thư giãn</h3>
        <div className="aspect-video w-full max-w-lg mx-auto bg-black rounded-lg overflow-hidden shadow-lg mb-4">
            <iframe
                width="100%"
                height="100%"
                src="https://www.youtube.com/embed/3pTW57TDoDo?autoplay=1&list=RD3pTW57TDoDo"
                title="YouTube video player"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
            ></iframe>
        </div>
        <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-800">← Quay lại</button>
    </div>
);

const StoryReader: React.FC<{ story: typeof inspirationalStories[0], onBack: () => void, addToast: (msg: string) => void }> = ({ story, onBack, addToast }) => {
    return (
        <div className="text-left w-full p-2 md:p-4">
            <div className="text-center mb-4">
                <div className="text-4xl mb-2">{story.emoji}</div>
                <h4 className="text-xl font-bold text-gray-800">{story.title}</h4>
            </div>
            <div className="text-gray-700 leading-relaxed space-y-3 mb-4">
                {story.content.split('\n\n').map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                ))}
            </div>
            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 my-4 rounded-r-lg text-gray-800">
                <strong>Bài học:</strong> {story.lesson}
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 my-6">
                <button onClick={() => addToast(`💭 Đã lưu cảm nhận về câu chuyện!`)} className="bg-blue-500 text-white px-5 py-2 rounded-lg hover:bg-blue-600 transition-colors w-full sm:w-auto">
                    🗣️ Chia sẻ cảm nhận
                </button>
                <button onClick={onBack} className="bg-gray-200 text-gray-800 px-5 py-2 rounded-lg hover:bg-gray-300 transition-colors w-full sm:w-auto">
                    📚 Đọc câu chuyện khác
                </button>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 mt-6">
                <h4 className="font-semibold mb-2 text-gray-800">💡 Sau khi đọc câu chuyện</h4>
                <ul className="text-sm text-gray-700 space-y-1 list-disc list-inside">
                    <li>Suy ngẫm về thông điệp chính</li>
                    <li>Áp dụng bài học vào cuộc sống</li>
                    <li>Chia sẻ cảm nhận với bạn bè</li>
                    <li>Ghi nhớ những điều tích cực</li>
                </ul>
            </div>
        </div>
    );
};

const StorySelector: React.FC<{ onSelectStory: (story: any) => void, onBack: () => void }> = ({ onSelectStory, onBack }) => {
    const storyButtons = [
        { ...inspirationalStories[0], color: 'bg-blue-500 hover:bg-blue-600' },
        { ...inspirationalStories[1], color: 'bg-green-500 hover:bg-green-600' },
        { ...inspirationalStories[2], color: 'bg-purple-500 hover:bg-purple-600' },
        { ...inspirationalStories[3], color: 'bg-orange-500 hover:bg-orange-600' },
        { ...inspirationalStories[4], color: 'bg-pink-500 hover:bg-pink-600' },
        { ...inspirationalStories[5], color: 'bg-teal-500 hover:bg-teal-600' },
    ];
    
    const selectRandom = () => {
        const randomIndex = Math.floor(Math.random() * inspirationalStories.length);
        onSelectStory(inspirationalStories[randomIndex]);
    };

    return (
        <div className="text-center w-full max-w-lg mx-auto">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">📖 Góc cảm hứng</h3>
            <p className="text-gray-600 mb-6">Chọn một câu chuyện để tìm nguồn động lực cho hôm nay.</p>
            <div className="bg-white rounded-lg p-4 shadow-md mb-6">
                 <h4 className="font-semibold mb-3 text-gray-800">✨ Chọn câu chuyện truyền cảm hứng</h4>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {storyButtons.map(story => (
                        <button key={story.id} onClick={() => onSelectStory(story)} className={`${story.color} text-white px-4 py-3 rounded-lg transition-colors font-semibold flex items-center justify-center gap-2`}>
                           {story.emoji} {story.title}
                        </button>
                    ))}
                     <button onClick={selectRandom} className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-3 rounded-lg transition-colors font-semibold flex items-center justify-center gap-2 md:col-span-2">
                        🎲 Câu chuyện ngẫu nhiên
                     </button>
                 </div>
            </div>
            <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-800">← Quay lại</button>
        </div>
    );
};


export const ZenRoomModule: React.FC<ZenRoomModuleProps> = ({ onClose, recordActivity, addToast, updateHappyPoints }) => {
    type ZenArea = 'menu' | 'meditation' | 'bell' | 'music' | 'story_selection' | 'story_view';
    const [activeArea, setActiveArea] = useState<ZenArea>('menu');
    const [selectedStory, setSelectedStory] = useState<any>(null);

    const handleSelectStory = (story: any) => {
        setSelectedStory(story);
        setActiveArea('story_view');
        recordActivity('zen-room', `Đọc câu chuyện: ${story.title}`);
    };

    const renderContent = () => {
        switch (activeArea) {
            case 'meditation':
                return <MeditationPractice onBack={() => setActiveArea('menu')} addToast={addToast} updateHappyPoints={updateHappyPoints} recordActivity={recordActivity} />;
            case 'bell':
                return <MeditationBell onBack={() => setActiveArea('menu')} />;
            case 'music':
                return <YouTubePlayer onBack={() => setActiveArea('menu')} />;
            case 'story_selection':
                return <StorySelector onSelectStory={handleSelectStory} onBack={() => setActiveArea('menu')} />;
            case 'story_view':
                return selectedStory && <StoryReader story={selectedStory} onBack={() => setActiveArea('story_selection')} addToast={addToast} />;
            case 'menu':
            default:
                return (
                    <div className="grid grid-cols-2 gap-3 md:gap-4">
                         <button onClick={() => setActiveArea('meditation')} className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white p-3 md:p-4 rounded-lg transition-all transform hover:scale-105 shadow-lg">
                            <div className="text-4xl md:text-5xl mb-2">🧘‍♀️</div>
                            <div className="font-bold text-sm md:text-base">Thiền định</div>
                        </button>
                         <button onClick={() => setActiveArea('bell')} className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white p-3 md:p-4 rounded-lg transition-all transform hover:scale-105 shadow-lg">
                            <div className="text-4xl md:text-5xl mb-2">🔔</div>
                            <div className="font-bold text-sm md:text-base">Cái mõ thiền</div>
                        </button>
                         <button onClick={() => setActiveArea('music')} className="bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white p-3 md:p-4 rounded-lg transition-all transform hover:scale-105 shadow-lg">
                            <div className="text-4xl md:text-5xl mb-2">🎵</div>
                            <div className="font-bold text-sm md:text-base">Nhạc thư giãn</div>
                        </button>
                         <button onClick={() => setActiveArea('story_selection')} className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white p-3 md:p-4 rounded-lg transition-all transform hover:scale-105 shadow-lg">
                            <div className="text-4xl md:text-5xl mb-2">📖</div>
                            <div className="font-bold text-sm md:text-base">Truyền cảm hứng</div>
                        </button>
                    </div>
                );
        }
    };

    return (
        <div className="p-4 md:p-6">
            <div className="flex justify-between items-center mb-4 md:mb-6">
                <h2 className="text-lg md:text-2xl font-bold text-gray-800">🧘 Phòng thư giãn ảo - ZenRoom</h2>
                <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-xl md:text-2xl">&times;</button>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-4 md:p-6 min-h-[450px] flex items-center justify-center">
                {renderContent()}
            </div>
        </div>
    );
};