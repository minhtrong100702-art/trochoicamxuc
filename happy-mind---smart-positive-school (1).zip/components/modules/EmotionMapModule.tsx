
import React from 'react';
import { Emotion } from '../../types';

interface EmotionMapModuleProps {
    onRecordEmotion: (emotion: Emotion) => void;
    onClose: () => void;
    onViewData: () => void;
}

const emotionButtons: { emotion: Emotion; label: string; icon: string; bg: string; }[] = [
    { emotion: 'very-happy', label: 'Rất vui', icon: '😄', bg: 'bg-green-100 hover:bg-green-200' },
    { emotion: 'happy', label: 'Vui', icon: '😊', bg: 'bg-blue-100 hover:bg-blue-200' },
    { emotion: 'neutral', label: 'Bình thường', icon: '😐', bg: 'bg-yellow-100 hover:bg-yellow-200' },
    { emotion: 'sad', label: 'Buồn', icon: '😔', bg: 'bg-orange-100 hover:bg-orange-200' },
    { emotion: 'stressed', label: 'Căng thẳng', icon: '😰', bg: 'bg-red-100 hover:bg-red-200' },
];

export const EmotionMapModule: React.FC<EmotionMapModuleProps> = ({ onRecordEmotion, onClose, onViewData }) => {
    return (
        <div className="p-4 md:p-6">
            <div className="flex justify-between items-center mb-4 md:mb-6">
                <h2 className="text-lg md:text-2xl font-bold text-gray-800">💬 Bản đồ cảm xúc lớp học</h2>
                <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-xl md:text-2xl">&times;</button>
            </div>
            <div className="mb-4 md:mb-6">
                <h3 className="text-base md:text-lg font-semibold mb-3">Hôm nay bạn cảm thấy thế nào?</h3>
                <div className="grid grid-cols-3 md:grid-cols-5 gap-2 md:gap-3">
                    {emotionButtons.map(({ emotion, label, icon, bg }) => (
                        <button key={emotion} onClick={() => onRecordEmotion(emotion)} className={`${bg} p-2 md:p-3 rounded-lg text-center transition-colors`}>
                            <div className="text-2xl md:text-3xl mb-1">{icon}</div>
                            <div className="text-xs md:text-sm">{label}</div>
                        </button>
                    ))}
                </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3 md:p-4 mb-4">
                <h4 className="font-semibold mb-2 text-sm md:text-base">🎯 Cảm xúc sẽ được lưu vào dữ liệu lớp học</h4>
                <p className="text-xs md:text-sm text-gray-600 mb-3">Thông tin cảm xúc của bạn sẽ giúp giáo viên hiểu rõ hơn về tình trạng lớp học</p>
                <button onClick={onViewData} className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors text-sm">
                    📊 Xem dữ liệu cảm xúc lớp
                </button>
            </div>
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-3 md:p-4">
                <h4 className="font-semibold mb-2 text-sm md:text-base">💡 Mẹo cải thiện cảm xúc</h4>
                <div className="text-xs md:text-sm text-gray-700 space-y-1">
                    <div>• Thở sâu 3 lần khi cảm thấy căng thẳng</div>
                    <div>• Chia sẻ cảm xúc với bạn bè hoặc giáo viên</div>
                    <div>• Tham gia các hoạt động thư giãn trong ZenRoom</div>
                </div>
            </div>
        </div>
    );
};