
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { audioService } from '../../services/audioService';

interface SmartBreakModuleProps {
    onClose: () => void;
    addToast: (message: string) => void;
}

type Game = 'menu' | 'breathing' | 'memory' | 'color' | 'stretching';

// --- Breathing Game Component ---
const BreathingGame: React.FC<{ onBack: () => void; addToast: (msg: string) => void }> = ({ onBack, addToast }) => {
    const [duration, setDuration] = useState<number | null>(null);
    const [timeLeft, setTimeLeft] = useState(0);
    const [isActive, setIsActive] = useState(false);
    const [isBreathingIn, setIsBreathingIn] = useState(true);
    const timerRef = useRef<number | null>(null);
    const breathTimerRef = useRef<number | null>(null);

    const cleanupTimers = useCallback(() => {
        if (timerRef.current) clearInterval(timerRef.current);
        if (breathTimerRef.current) clearInterval(breathTimerRef.current);
    }, []);

    useEffect(() => {
        return cleanupTimers;
    }, [cleanupTimers]);

    const startSession = (minutes: number) => {
        cleanupTimers();
        const totalSeconds = minutes * 60;
        setDuration(totalSeconds);
        setTimeLeft(totalSeconds);
        setIsActive(true);
        setIsBreathingIn(true);
        addToast(`Bắt đầu bài tập hít thở ${minutes} phút! 🫁`);
        audioService.playSound('zen');

        timerRef.current = window.setInterval(() => {
            setTimeLeft(prev => {
                if (prev <= 1) {
                    cleanupTimers();
                    setIsActive(false);
                    setDuration(null);
                    addToast("🎉 Hoàn thành bài tập hít thở!");
                    audioService.playSound('success');
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);

        breathTimerRef.current = window.setInterval(() => {
            setIsBreathingIn(prev => !prev);
        }, 4000);
    };

    const stopSession = () => {
        cleanupTimers();
        setIsActive(false);
        setDuration(null);
        addToast("Đã dừng bài tập hít thở.");
    };

    if (!isActive) {
        return (
            <div className="text-center">
                 <h3 className="text-lg md:text-xl font-semibold text-gray-700 mb-4">Trò chơi hít thở</h3>
                 <p className="text-sm text-gray-600 mb-6">Chọn thời gian để bắt đầu bài tập hít thở thư giãn.</p>
                <div className="flex justify-center gap-3 mb-6">
                    <button onClick={() => startSession(2)} className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">2 phút</button>
                    <button onClick={() => startSession(3)} className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600">3 phút</button>
                    <button onClick={() => startSession(5)} className="bg-purple-500 text-white px-4 py-2 rounded-lg hover:bg-purple-600">5 phút</button>
                </div>
                 <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-800">← Quay lại</button>
            </div>
        );
    }

    return (
        <div className="text-center">
            <div className="mb-4">
                <div 
                    className="breathing-circle w-40 h-40 mx-auto bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg"
                    style={{ transform: `scale(${isBreathingIn ? 1.2 : 1})` }}
                >
                    {isBreathingIn ? 'Hít vào' : 'Thở ra'}
                </div>
            </div>
            <div className="text-3xl font-bold mb-4">{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60).toString().padStart(2, '0')}`}</div>
            <button onClick={stopSession} className="bg-red-500 text-white px-5 py-2 rounded-lg hover:bg-red-600">Dừng</button>
        </div>
    );
};

// --- Memory Game Component ---
const EMOJIS = ['😊', '🌟', '🧠', '🌈', '🎯', '🧘', '💡', '🚀'];
const MemoryGame: React.FC<{ onBack: () => void; addToast: (msg: string) => void }> = ({ onBack, addToast }) => {
    const [cards, setCards] = useState<{ emoji: string; isFlipped: boolean; isMatched: boolean }[]>([]);
    const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
    const [moves, setMoves] = useState(0);
    const [isGameWon, setIsGameWon] = useState(false);
    const timeoutRef = useRef<number | null>(null);

    const shuffleCards = useCallback(() => {
        const shuffled = [...EMOJIS, ...EMOJIS]
            .sort(() => Math.random() - 0.5)
            .map(emoji => ({ emoji, isFlipped: false, isMatched: false }));
        setCards(shuffled);
        setMoves(0);
        setFlippedIndices([]);
        setIsGameWon(false);
    }, []);

    useEffect(() => {
        shuffleCards();
    }, [shuffleCards]);
    
    useEffect(() => {
        if (flippedIndices.length === 2) {
            const [firstIndex, secondIndex] = flippedIndices;
            if (cards[firstIndex].emoji === cards[secondIndex].emoji) {
                const newCards = cards.map((card, index) => 
                    index === firstIndex || index === secondIndex ? { ...card, isMatched: true } : card
                );
                setCards(newCards);
                setFlippedIndices([]);
                if (newCards.every(card => card.isMatched)) {
                     setIsGameWon(true);
                     addToast(`🎉 Chúc mừng! Bạn đã thắng sau ${moves + 1} lượt!`);
                     audioService.playSound('celebration');
                }
            } else {
                timeoutRef.current = window.setTimeout(() => {
                    setCards(prev => prev.map((card, index) => 
                        index === firstIndex || index === secondIndex ? { ...card, isFlipped: false } : card
                    ));
                    setFlippedIndices([]);
                }, 1000);
            }
            setMoves(prev => prev + 1);
        }
        return () => { if(timeoutRef.current) clearTimeout(timeoutRef.current); };
    }, [flippedIndices, cards, moves, addToast]);

    const handleCardClick = (index: number) => {
        if (flippedIndices.length === 2 || cards[index].isFlipped || cards[index].isMatched) return;
        
        setCards(prev => prev.map((card, i) => i === index ? { ...card, isFlipped: true } : card));
        setFlippedIndices(prev => [...prev, index]);
    };

    return (
        <div className="text-center w-full max-w-xs mx-auto">
            <div className="flex justify-between items-center mb-4">
                 <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-800">← Quay lại</button>
                 <h3 className="text-lg md:text-xl font-semibold text-gray-700">Trò chơi trí nhớ</h3>
                 <span className="text-sm font-bold">Lượt: {moves}</span>
            </div>
            
            {isGameWon ? (
                <div className="min-h-[250px] flex flex-col items-center justify-center">
                    <div className="text-4xl mb-4">🎉</div>
                    <h4 className="text-xl font-bold text-green-600">Bạn đã chiến thắng!</h4>
                    <p className="text-gray-600">Tuyệt vời! Bạn đã hoàn thành sau {moves} lượt.</p>
                </div>
            ) : (
                <div className="grid grid-cols-4 gap-3 md:gap-4 mb-4">
                    {cards.map((card, index) => (
                        <div key={index} className="perspective w-full aspect-square" onClick={() => handleCardClick(index)}>
                            <div className={`relative transform-style-preserve-3d transition-transform duration-500 w-full h-full ${card.isFlipped || card.isMatched ? 'rotate-y-180' : ''}`}>
                                <div className="absolute w-full h-full backface-hidden bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center text-3xl text-white shadow-md cursor-pointer">?</div>
                                <div className={`absolute w-full h-full backface-hidden rotate-y-180 ${card.isMatched ? 'bg-green-200' : 'bg-blue-100'} rounded-lg flex items-center justify-center text-3xl md:text-4xl shadow-md`}>{card.emoji}</div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
             <button onClick={shuffleCards} className="bg-purple-500 text-white px-5 py-2 rounded-lg hover:bg-purple-600 transition-colors">Chơi lại</button>
        </div>
    );
};

// --- Color Game Component ---
const ColorGame: React.FC<{ onBack: () => void; addToast: (msg: string) => void }> = ({ onBack, addToast }) => {
    const [targetColor, setTargetColor] = useState({ r: 0, g: 0, b: 0 });
    const [currentColor, setCurrentColor] = useState({ r: 128, g: 128, b: 128 });
    const [matchPercent, setMatchPercent] = useState<number | null>(null);

    const generateRandomColor = useCallback(() => {
        setTargetColor({
            r: Math.floor(Math.random() * 256),
            g: Math.floor(Math.random() * 256),
            b: Math.floor(Math.random() * 256),
        });
        setCurrentColor({ r: 128, g: 128, b: 128 });
        setMatchPercent(null);
    }, []);

    useEffect(() => {
        generateRandomColor();
    }, [generateRandomColor]);

    const checkMatch = () => {
        const diffR = targetColor.r - currentColor.r;
        const diffG = targetColor.g - currentColor.g;
        const diffB = targetColor.b - currentColor.b;
        const distance = Math.sqrt(diffR * diffR + diffG * diffG + diffB * diffB);
        const maxDistance = Math.sqrt(3 * 255 * 255);
        const percentage = Math.max(0, 100 - (distance / maxDistance) * 100);
        setMatchPercent(percentage);

        if (percentage > 95) {
            addToast(`🎉 Tuyệt vời! Độ chính xác: ${percentage.toFixed(1)}%`);
            audioService.playSound('success');
            setTimeout(generateRandomColor, 1500);
        } else {
            addToast(`Độ chính xác: ${percentage.toFixed(1)}%. Thử lại nhé!`);
        }
    };

    return (
        <div className="text-center w-full max-w-md mx-auto">
            <div className="flex justify-between items-center mb-4">
                 <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-800">← Quay lại</button>
                 <h3 className="text-lg md:text-xl font-semibold text-gray-700">Trò chơi màu sắc</h3>
                 <button onClick={generateRandomColor} className="text-sm text-gray-600 hover:text-gray-800">Màu mới 🔄</button>
            </div>
            <p className="text-sm text-gray-600 mb-4">Hãy pha màu sao cho giống với "Màu mục tiêu".</p>
            <div className="flex justify-around mb-4">
                <div>
                    <p className="font-semibold">Màu của bạn</p>
                    <div className="w-24 h-24 rounded-lg shadow-inner border" style={{ backgroundColor: `rgb(${currentColor.r}, ${currentColor.g}, ${currentColor.b})` }}></div>
                </div>
                <div>
                    <p className="font-semibold">Màu mục tiêu</p>
                    <div className="w-24 h-24 rounded-lg shadow-inner border" style={{ backgroundColor: `rgb(${targetColor.r}, ${targetColor.g}, ${targetColor.b})` }}></div>
                </div>
            </div>
            <div className="space-y-3 mb-4">
                <div><input type="range" min="0" max="255" value={currentColor.r} onChange={(e) => setCurrentColor(c => ({...c, r: +e.target.value}))} className="w-full accent-red-500" /></div>
                <div><input type="range" min="0" max="255" value={currentColor.g} onChange={(e) => setCurrentColor(c => ({...c, g: +e.target.value}))} className="w-full accent-green-500" /></div>
                <div><input type="range" min="0" max="255" value={currentColor.b} onChange={(e) => setCurrentColor(c => ({...c, b: +e.target.value}))} className="w-full accent-blue-500" /></div>
            </div>
            {matchPercent !== null && (
                 <p className="text-lg font-bold mb-4" style={{ color: matchPercent > 95 ? 'green' : 'orange' }}>
                     Độ chính xác: {matchPercent.toFixed(1)}%
                 </p>
            )}
            <button onClick={checkMatch} className="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600">Kiểm tra</button>
        </div>
    );
};


// --- Stretching Game Component ---
const stretches = [
    { emoji: '🧘', name: 'Vươn vai', duration: 20, instruction: 'Đưa hai tay lên cao và vươn người, hít thở sâu.' },
    { emoji: '🙆', name: 'Nghiêng lườn', duration: 15, instruction: 'Nghiêng người sang trái, giữ 10 giây, sau đó đổi bên.' },
    { emoji: '🔄', name: 'Xoay cổ', duration: 20, instruction: 'Từ từ xoay cổ theo chiều kim đồng hồ, rồi ngược lại.' },
    { emoji: '🙌', name: 'Giãn cơ tay', duration: 15, instruction: 'Đưa thẳng tay phải qua ngực, dùng tay trái ép nhẹ.' },
    { emoji: '🚶', name: 'Đứng lên đi lại', duration: 30, instruction: 'Đứng dậy, đi lại nhẹ nhàng và thả lỏng cơ thể.' },
];
const StretchingGame: React.FC<{ onBack: () => void; addToast: (msg: string) => void }> = ({ onBack, addToast }) => {
    const [currentStretch, setCurrentStretch] = useState(0);
    const [timeLeft, setTimeLeft] = useState(stretches[0].duration);
    const timerRef = useRef<number | null>(null);

    const cleanupTimer = useCallback(() => {
        if (timerRef.current) clearInterval(timerRef.current);
    }, []);

    useEffect(() => {
        cleanupTimer();
        setTimeLeft(stretches[currentStretch].duration);

        timerRef.current = window.setInterval(() => {
            setTimeLeft(prev => {
                if (prev <= 1) {
                    if (currentStretch < stretches.length - 1) {
                        setCurrentStretch(s => s + 1);
                    } else {
                        cleanupTimer();
                        addToast('🎉 Hoàn thành bài tập vận động!');
                        audioService.playSound('success');
                    }
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
        
        return cleanupTimer;
    }, [currentStretch, addToast, cleanupTimer]);


    const isFinished = currentStretch === stretches.length - 1 && timeLeft <= 1;

    return (
        <div className="text-center w-full max-w-sm mx-auto">
            <div className="flex justify-between items-center mb-4">
                 <button onClick={onBack} className="text-sm text-gray-600 hover:text-gray-800">← Quay lại</button>
                 <h3 className="text-lg md:text-xl font-semibold text-gray-700">Trò chơi vận động</h3>
                 <span className="text-sm font-bold">{currentStretch + 1}/{stretches.length}</span>
            </div>

            {isFinished ? (
                 <div className="min-h-[250px] flex flex-col items-center justify-center">
                    <div className="text-4xl mb-4">🤸</div>
                    <h4 className="text-xl font-bold text-green-600">Bài tập hoàn tất!</h4>
                    <p className="text-gray-600">Cơ thể bạn chắc chắn cảm thấy tốt hơn nhiều rồi!</p>
                     <button onClick={() => setCurrentStretch(0)} className="mt-4 bg-purple-500 text-white px-5 py-2 rounded-lg hover:bg-purple-600">Thực hiện lại</button>
                </div>
            ) : (
                <div className="min-h-[250px]">
                    <div className="text-6xl mb-3">{stretches[currentStretch].emoji}</div>
                    <h4 className="text-xl font-bold mb-2">{stretches[currentStretch].name}</h4>
                    <p className="text-gray-600 mb-4 h-12">{stretches[currentStretch].instruction}</p>
                    <div className="text-4xl font-bold text-blue-600 mb-4">{timeLeft}</div>
                     <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${((stretches[currentStretch].duration - timeLeft) / stretches[currentStretch].duration) * 100}%` }}></div>
                    </div>
                </div>
            )}
        </div>
    );
};


// --- Main Component ---
export const SmartBreakModule: React.FC<SmartBreakModuleProps> = ({ onClose, addToast }) => {
    const [activeGame, setActiveGame] = useState<Game>('menu');

    const renderContent = () => {
        switch(activeGame) {
            case 'breathing':
                return <BreathingGame onBack={() => setActiveGame('menu')} addToast={addToast} />;
            case 'memory':
                return <MemoryGame onBack={() => setActiveGame('menu')} addToast={addToast} />;
            case 'color':
                return <ColorGame onBack={() => setActiveGame('menu')} addToast={addToast} />;
            case 'stretching':
                return <StretchingGame onBack={() => setActiveGame('menu')} addToast={addToast} />;
            case 'menu':
            default:
                return (
                     <div className="grid grid-cols-2 gap-3 md:gap-4">
                        <button onClick={() => setActiveGame('breathing')} className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white p-3 md:p-4 rounded-lg transition-all transform hover:scale-105 shadow-lg">
                            <div className="text-2xl md:text-3xl mb-1 md:mb-2">🫁</div>
                            <div className="font-bold text-sm md:text-base">Trò chơi hít thở</div>
                        </button>
                        <button onClick={() => setActiveGame('color')} className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white p-3 md:p-4 rounded-lg transition-all transform hover:scale-105 shadow-lg">
                            <div className="text-2xl md:text-3xl mb-1 md:mb-2">🌈</div>
                            <div className="font-bold text-sm md:text-base">Trò chơi màu sắc</div>
                        </button>
                        <button onClick={() => setActiveGame('memory')} className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white p-3 md:p-4 rounded-lg transition-all transform hover:scale-105 shadow-lg">
                            <div className="text-2xl md:text-3xl mb-1 md:mb-2">🧠</div>
                            <div className="font-bold text-sm md:text-base">Trò chơi trí nhớ</div>
                        </button>
                        <button onClick={() => setActiveGame('stretching')} className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white p-3 md:p-4 rounded-lg transition-all transform hover:scale-105 shadow-lg">
                            <div className="text-2xl md:text-3xl mb-1 md:mb-2">🤸</div>
                            <div className="font-bold text-sm md:text-base">Trò chơi vận động</div>
                        </button>
                    </div>
                );
        }
    }

    return (
        <div className="p-4 md:p-6">
            <div className="flex justify-between items-center mb-4 md:mb-6">
                <h2 className="text-lg md:text-2xl font-bold text-gray-800">🎮 Trò chơi thư giãn</h2>
                <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-xl md:text-2xl">&times;</button>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-4 md:p-6 min-h-[400px] flex items-center justify-center">
               {renderContent()}
            </div>
        </div>
    );
};