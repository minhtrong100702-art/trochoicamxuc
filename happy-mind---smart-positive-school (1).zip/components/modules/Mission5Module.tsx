
import React, { useState, useEffect } from 'react';
import { audioService } from '../../services/audioService';

interface Mission5ModuleProps {
    onClose: () => void;
    addToast: (message: string) => void;
}

// --- Expanded Question Bank ---
const questions = [
    // Knowledge
    { id: 1, category: 'knowledge', text: '"Trăm hay không bằng tay quen." thuộc thể loại nào?', options: ['Tục ngữ', 'Thành ngữ', 'Ca dao', 'Châm ngôn'], correctAnswer: 'Tục ngữ' },
    { id: 2, category: 'knowledge', text: 'Một hình chữ nhật có chu vi 30cm và chiều dài 10cm. Chiều rộng là bao nhiêu?', options: ['5cm', '10cm', '15cm', '20cm'], correctAnswer: '5cm' },
    { id: 3, category: 'knowledge', text: 'What is the opposite of "brave"?', options: ['Scared', 'Cowardly', 'Timid', 'Afraid'], correctAnswer: 'Cowardly' },
    { id: 4, category: 'knowledge', text: 'Ai là tác giả của "Bình Ngô Đại Cáo"?', options: ['Nguyễn Trãi', 'Nguyễn Du', 'Hồ Chí Minh', 'Lê Lợi'], correctAnswer: 'Nguyễn Trãi' },
    { id: 5, category: 'knowledge', text: '3 x (4 + 5) = ?', options: ['17', '27', '19', '32'], correctAnswer: '27' },
    { id: 6, category: 'knowledge', text: 'Choose the correct sentence: "She ___ to school every day."', options: ['go', 'goes', 'went', 'is going'], correctAnswer: 'goes' },
    { id: 7, category: 'knowledge', text: 'Thủ đô của nước Pháp là gì?', options: ['London', 'Berlin', 'Madrid', 'Paris'], correctAnswer: 'Paris' },
    { id: 8, category: 'knowledge', text: 'Hành tinh nào gần Mặt Trời nhất?', options: ['Sao Kim', 'Sao Hỏa', 'Sao Thủy', 'Trái Đất'], correctAnswer: 'Sao Thủy' },
    { id: 9, category: 'knowledge', text: 'Từ nào sau đây viết đúng chính tả?', options: ['Chín chắn', 'Chín chắng', 'Chín chấn', 'Chín cháng'], correctAnswer: 'Chín chắn' },
    { id: 10, category: 'knowledge', text: 'If yesterday was Friday, what is tomorrow?', options: ['Saturday', 'Sunday', 'Monday', 'Thursday'], correctAnswer: 'Sunday' },
    { id: 11, category: 'knowledge', text: 'Trong bài thơ "Lượm", chú bé Lượm làm nhiệm vụ gì?', options: ['Giao liên', 'Trinh sát', 'Nấu cơm', 'Chăn trâu'], correctAnswer: 'Giao liên' },
    { id: 12, category: 'knowledge', text: 'Số nào là số nguyên tố?', options: ['9', '15', '17', '21'], correctAnswer: '17' },
    { id: 21, category: 'knowledge', text: 'Nước chiếm bao nhiêu phần trăm bề mặt Trái Đất?', options: ['51%', '61%', '71%', '81%'], correctAnswer: '71%' },
    { id: 22, category: 'knowledge', text: '"Đi một ngày đàng, học một sàng khôn." có ý nghĩa gì?', options: ['Đi chơi vui vẻ', 'Đi nhiều sẽ mệt', 'Đi nhiều nơi sẽ học được nhiều điều', 'Ở nhà tốt hơn'], correctAnswer: 'Đi nhiều nơi sẽ học được nhiều điều' },
    { id: 23, category: 'knowledge', text: 'What is 15% of 200?', options: ['15', '20', '30', '40'], correctAnswer: '30' },
    { id: 24, category: 'knowledge', text: 'Ai là người đã lãnh đạo cuộc khởi nghĩa Hai Bà Trưng?', options: ['Trưng Trắc & Trưng Nhị', 'Bà Triệu', 'Lý Thường Kiệt', 'Trần Hưng Đạo'], correctAnswer: 'Trưng Trắc & Trưng Nhị' },
    { id: 25, category: 'knowledge', text: 'Đâu là ngọn núi cao nhất Việt Nam?', options: ['Fansipan', 'Pu Si Lung', 'Tây Côn Lĩnh', 'Bà Đen'], correctAnswer: 'Fansipan' },

    // Emotion
    { id: 13, category: 'emotion', text: 'Hôm nay, khi học bài, bạn cảm thấy thế nào nhất?', options: ['😄', '🤔', '😊', '😥'], correctAnswer: null },
    { id: 14, category: 'emotion', text: 'Biểu tượng nào thể hiện cảm giác "tò mò, muốn khám phá"?', options: ['💡', '😴', '😠', '🎉'], correctAnswer: null },
    { id: 15, category: 'emotion', text: 'Khi gặp một bài toán khó, cảm xúc đầu tiên của bạn là gì?', options: ['💪', '🤯', '🤔', '😒'], correctAnswer: null },
    { id: 16, category: 'emotion', text: 'Khi được điểm cao, bạn sẽ chọn biểu tượng nào?', options: ['🎉', '😎', '💖', '💯'], correctAnswer: null },
    { id: 26, category: 'emotion', text: 'Khi làm việc nhóm, bạn cảm thấy vui nhất khi nào?', options: ['🤝', '💡', '🏆', '🗣️'], correctAnswer: null },
    { id: 27, category: 'emotion', text: 'Cảm giác của bạn khi giúp đỡ một người bạn hiểu bài là gì?', options: ['💖', '😊', '😎', '✨'], correctAnswer: null },

    // Team
    { id: 17, category: 'team', text: 'Ai là người truyền cảm hứng học tập cho bạn trong lớp?', options: [], correctAnswer: null },
    { id: 18, category: 'team', text: 'Viết một lời động viên ngắn gửi đến một người bạn.', options: [], correctAnswer: null },
    { id: 19, category: 'team', text: 'Điều gì ở lớp làm bạn vui nhất?', options: [], correctAnswer: null },
    { id: 20, category: 'team', text: 'Kể một hành động tốt của bạn bè mà bạn nhớ mãi.', options: [], correctAnswer: null },
    { id: 28, category: 'team', text: 'Nếu có một điều ước cho lớp mình, bạn sẽ ước gì?', options: [], correctAnswer: null },
    { id: 29, category: 'team', text: 'Đâu là kỷ niệm đáng nhớ nhất của bạn với lớp?', options: [], correctAnswer: null },
    { id: 30, category: 'team', text: 'Hãy nói "cảm ơn" một người bạn trong lớp và vì sao.', options: [], correctAnswer: null },
    { id: 31, category: 'knowledge', text: 'Vua Hùng đã có công gì với nước ta?', options: ['Dựng nước', 'Giữ nước', 'Phát minh ra chữ viết', 'Xây dựng kinh đô'], correctAnswer: 'Dựng nước' },
    { id: 32, category: 'knowledge', text: 'How many continents are there in the world?', options: ['5', '6', '7', '8'], correctAnswer: '7' },
    { id: 33, category: 'knowledge', text: 'Trong phép chia, số bị chia là 56, số chia là 8. Thương là bao nhiêu?', options: ['6', '7', '8', '9'], correctAnswer: '7' },
    { id: 34, category: 'knowledge', text: 'Ai là nữ hoàng đầu tiên của Việt Nam?', options: ['Dương Vân Nga', 'Lý Chiêu Hoàng', 'Ỷ Lan', 'Trưng Trắc'], correctAnswer: 'Trưng Trắc' },
    { id: 35, category: 'knowledge', text: 'Con vật nào sau đây không phải là động vật có vú?', options: ['Cá voi', 'Dơi', 'Cá sấu', 'Hà mã'], correctAnswer: 'Cá sấu' },
    { id: 36, category: 'knowledge', text: 'Ai là người dẹp loạn 12 sứ quân, thống nhất đất nước?', options: ['Lê Hoàn', 'Ngô Quyền', 'Lý Công Uẩn', 'Đinh Bộ Lĩnh'], correctAnswer: 'Đinh Bộ Lĩnh' },
    { id: 37, category: 'knowledge', text: 'Quá trình cây xanh sử dụng ánh sáng mặt trời để tạo năng lượng gọi là gì?', options: ['Hô hấp', 'Quang hợp', 'Trao đổi chất', 'Bay hơi'], correctAnswer: 'Quang hợp' },
    { id: 38, category: 'knowledge', text: 'Which word is a synonym for "happy"?', options: ['Sad', 'Angry', 'Joyful', 'Tired'], correctAnswer: 'Joyful' },
    { id: 39, category: 'emotion', text: 'Khi bạn hoàn thành một bài tập rất khó, bạn cảm thấy thế nào?', options: ['😌', '🏆', '🤯', '💪'], correctAnswer: null },
    { id: 40, category: 'team', text: 'Bạn sẽ làm gì để giúp một người bạn đang gặp khó khăn trong học tập?', options: [], correctAnswer: null }
];

const shuffleArray = (array: any[]) => [...array].sort(() => Math.random() - 0.5);

export const Mission5Module: React.FC<Mission5ModuleProps> = ({ onClose, addToast }) => {
    const [gameStatus, setGameStatus] = useState<'idle' | 'playing' | 'finished'>('idle');
    const [challengeQuestions, setChallengeQuestions] = useState<typeof questions>([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [score, setScore] = useState(0);
    const [teamInput, setTeamInput] = useState('');
    const [answerStatus, setAnswerStatus] = useState<'correct' | 'incorrect' | null>(null);
    const [selectedOption, setSelectedOption] = useState<string | null>(null);

    const [stats, setStats] = useState(() => {
        const savedStats = localStorage.getItem('mission5Stats');
        return savedStats ? JSON.parse(savedStats) : { totalCorrect: 0, totalAnswered: 0, badges: 0 };
    });

    useEffect(() => {
        localStorage.setItem('mission5Stats', JSON.stringify(stats));
    }, [stats]);

    const handleStartChallenge = () => {
        const selectedQuestions = shuffleArray(questions).slice(0, 5);
        setChallengeQuestions(selectedQuestions);
        setCurrentQuestionIndex(0);
        setScore(0);
        setTeamInput('');
        setAnswerStatus(null);
        setSelectedOption(null);
        setGameStatus('playing');
        audioService.playSound('mission');
    };

    const handleAnswer = (answer: string) => {
        if (answerStatus) return; // Prevent answering multiple times

        const currentQuestion = challengeQuestions[currentQuestionIndex];
        const isCorrect = answer === currentQuestion.correctAnswer;
        let wasCorrect = false;

        setSelectedOption(answer);

        if (currentQuestion.category === 'knowledge') {
            if (isCorrect) {
                setAnswerStatus('correct');
                wasCorrect = true;
            } else {
                setAnswerStatus('incorrect');
            }
        } else { // Emotion or Team
            setAnswerStatus('correct');
            wasCorrect = true;
            if (currentQuestion.category === 'team') {
                addToast("Cảm ơn bạn đã chia sẻ! ✨");
            }
        }

        if (wasCorrect) {
            setScore(s => s + 1);
            setStats(prev => ({ ...prev, totalCorrect: prev.totalCorrect + 1, badges: prev.badges + 1 }));
            audioService.playSound('success');
        } else {
            audioService.playSound('error');
        }

        setStats(prev => ({ ...prev, totalAnswered: prev.totalAnswered + 1 }));

        setTimeout(() => {
            if (currentQuestionIndex < challengeQuestions.length - 1) {
                setCurrentQuestionIndex(i => i + 1);
                setTeamInput('');
                setAnswerStatus(null);
                setSelectedOption(null);
            } else {
                setGameStatus('finished');
            }
        }, 1500);
    };
    
    const handleTeamSubmit = () => {
        if (teamInput.trim() === '') {
            addToast("Hãy viết câu trả lời của bạn nhé!");
            return;
        }
        handleAnswer(teamInput);
    };

    const completionRate = stats.totalAnswered > 0 ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100) : 0;
    const badgeEmojis = ['🥇', '🥈', '🥉', '🏅', '🏆'];

    const renderGameContent = () => {
        const currentQuestion = challengeQuestions[currentQuestionIndex];

        switch (gameStatus) {
            case 'playing':
                return (
                    <div className="w-full max-w-lg mx-auto text-center">
                        <div className="mb-4">
                            <p className="font-bold text-purple-600">Câu hỏi {currentQuestionIndex + 1} / 5</p>
                            <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
                                <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: `${((currentQuestionIndex + 1) / 5) * 100}%` }}></div>
                            </div>
                        </div>

                        <p className="text-xl font-semibold text-gray-800 mb-6 min-h-[84px] flex items-center justify-center">{currentQuestion.text}</p>
                        
                        {currentQuestion.category === 'knowledge' && (
                            <div className="grid grid-cols-2 gap-3">
                                {currentQuestion.options.map((opt, i) => {
                                    const isSelected = selectedOption === opt;
                                    const isCorrect = opt === currentQuestion.correctAnswer;
                                    let buttonClass = 'bg-white hover:bg-blue-100 border-gray-300';
                                    if (answerStatus && isSelected) {
                                        buttonClass = answerStatus === 'correct' ? 'bg-green-500 border-green-600 text-white' : 'bg-red-500 border-red-600 text-white';
                                    } else if (answerStatus && isCorrect) {
                                        buttonClass = 'bg-green-500 border-green-600 text-white';
                                    }
                                    
                                    return (
                                        <button key={i} onClick={() => handleAnswer(opt)}
                                            className={`p-3 rounded-lg shadow-sm transition-all duration-300 border-2 font-semibold ${buttonClass}`}>
                                            {opt}
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                        {currentQuestion.category === 'emotion' && (
                             <div className="grid grid-cols-4 gap-3">
                                {currentQuestion.options.map((opt, i) => (
                                    <button key={i} onClick={() => handleAnswer(opt)}
                                        className="p-3 rounded-lg shadow-sm hover:bg-yellow-100 transition-all text-4xl transform hover:scale-110">
                                        {opt}
                                    </button>
                                ))}
                            </div>
                        )}
                        {currentQuestion.category === 'team' && (
                             <div className="flex flex-col items-center gap-3">
                                <textarea value={teamInput} onChange={(e) => setTeamInput(e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                                    placeholder="Viết câu trả lời của bạn ở đây..." rows={3}
                                />
                                <button onClick={handleTeamSubmit} className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-2 rounded-full font-semibold hover:scale-105 transition-transform">Gửi</button>
                            </div>
                        )}
                    </div>
                );
            case 'finished':
                const getResultMessage = () => {
                    if (score === 5) return { emoji: '🎉', text: 'Xuất sắc!', color: 'text-green-500' };
                    if (score >= 3) return { emoji: '👍', text: 'Làm tốt lắm!', color: 'text-blue-500' };
                    return { emoji: '😊', text: 'Cố gắng nhé!', color: 'text-orange-500' };
                };
                const result = getResultMessage();
                return (
                    <div className="text-center">
                        <div className="text-7xl mb-4 animate-bounce">{result.emoji}</div>
                        <h3 className={`text-3xl font-bold ${result.color} mb-2`}>{result.text}</h3>
                        <p className="text-gray-600 text-lg mb-6">Bạn đã hoàn thành với số điểm <span className="font-bold">{score}/{challengeQuestions.length}</span></p>
                        <button onClick={handleStartChallenge} className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-8 py-3 rounded-full font-semibold hover:scale-105 transition-transform shadow-lg">Chơi lại</button>
                    </div>
                );
            case 'idle':
            default:
                return (
                    <div className="w-full text-center">
                        <div className="bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-xl p-6 mb-6 shadow-lg transform hover:scale-105 transition-transform duration-300">
                            <h3 className="text-xl font-bold mb-2">Sẵn sàng cho thử thách?</h3>
                            <p className="mb-4 text-sm opacity-90">Hoàn thành 5 câu hỏi ngẫu nhiên để nhận huy hiệu và điểm thưởng!</p>
                            <button onClick={handleStartChallenge} className="bg-white text-purple-600 px-8 py-3 rounded-full font-bold hover:bg-gray-100 transition-colors text-lg shadow-md animate-pulse">
                                Bắt đầu!
                            </button>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-xl shadow-sm text-left">
                                <h4 className="font-bold text-blue-800 mb-2 flex items-center"><span className="text-2xl mr-2">🏆</span> Huy hiệu</h4>
                                <div className="text-3xl flex items-center gap-2">
                                    {Array.from({ length: Math.min(stats.badges, 5) }).map((_, i) => <span key={i}>{badgeEmojis[i]}</span>)}
                                    {stats.badges > 5 && <span className="text-base font-bold ml-2">+{stats.badges - 5}</span>}
                                    {stats.badges === 0 && <span className="text-base text-gray-500">Chưa có huy hiệu</span>}
                                </div>
                            </div>
                            <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-xl shadow-sm text-left">
                                <h4 className="font-bold text-green-800 mb-2 flex items-center"><span className="text-2xl mr-2">📊</span> Thống kê</h4>
                                <p className="font-semibold text-gray-700">Hoàn thành: <span className="text-green-600">{completionRate}%</span></p>
                                <p className="text-sm text-gray-600">Đúng: {stats.totalCorrect} / {stats.totalAnswered}</p>
                            </div>
                        </div>
                    </div>
                );
        }
    }

    return (
        <div className="p-4 md:p-6">
            <div className="flex justify-between items-center mb-4 md:mb-6">
                <h2 className="text-lg md:text-2xl font-bold text-gray-800">🎯 Mission 5′</h2>
                <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-xl md:text-2xl">&times;</button>
            </div>
            <div className="min-h-[400px] flex items-center justify-center bg-gradient-to-br from-gray-50 to-purple-50 rounded-lg p-4 transition-all duration-300">
                {renderGameContent()}
            </div>
        </div>
    );
};