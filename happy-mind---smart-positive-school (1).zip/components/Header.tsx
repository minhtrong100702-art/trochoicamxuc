
import React, { useState, useEffect } from 'react';
import { Screen } from '../types';

interface HeaderProps {
    userName: string;
    activeScreen: Screen;
    setActiveScreen: (screen: Screen) => void;
}

const navItems: { id: Screen, label: string }[] = [
    { id: 'home', label: 'Trang chủ' },
    { id: 'emotion-data', label: 'Dữ liệu cảm xúc' },
    { id: 'challenges', label: 'Thử thách' },
    { id: 'zen-room', label: 'Phòng Zen' },
    { id: 'events', label: 'Sự kiện' },
];

export const Header: React.FC<HeaderProps> = ({ userName, activeScreen, setActiveScreen }) => {
    const [visitorCount, setVisitorCount] = useState(Math.floor(Math.random() * 20) + 30); // Start with a random number e.g., 30-49

    useEffect(() => {
        const interval = setInterval(() => {
            setVisitorCount(prevCount => {
                const change = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
                const newCount = prevCount + change;
                return newCount < 20 ? 20 : newCount; // Ensure it doesn't go too low
            });
        }, 3000); // Update every 3 seconds

        return () => clearInterval(interval);
    }, []);

    return (
        <header className="gradient-bg text-white py-4 px-4 shadow-lg">
            <div className="max-w-6xl mx-auto">
                <div className="text-center mb-4">
                    <h1 className="text-2xl md:text-3xl font-bold mb-1">Happy Mind – Trường học tích cực thông minh</h1>
                    <p className="text-sm opacity-90">
                        Chào mừng <span className="font-bold">{userName}</span> đến với không gian học tập hạnh phúc!
                    </p>
                    <div className="flex items-center justify-center gap-2 text-xs mt-2 opacity-80">
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                      </span>
                      <span>{visitorCount} người đang truy cập</span>
                    </div>
                </div>
                <nav className="bg-white bg-opacity-20 rounded-lg p-2">
                    <div className="flex flex-wrap justify-center gap-2 text-sm">
                        {navItems.map(item => (
                            <button
                                key={item.id}
                                onClick={() => setActiveScreen(item.id)}
                                className={`nav-btn px-4 py-2 rounded-lg transition-colors ${activeScreen === item.id ? 'active' : ''}`}
                            >
                                {item.label}
                            </button>
                        ))}
                    </div>
                </nav>
            </div>
        </header>
    );
};