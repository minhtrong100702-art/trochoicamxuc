
import React, { useState } from 'react';

interface LoginScreenProps {
    onLogin: (name: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
    const [name, setName] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (name.trim()) {
            onLogin(name.trim());
        }
    };

    return (
        <div id="login-screen" className="min-h-full flex items-center justify-center bg-gradient-to-br from-purple-400 via-pink-500 to-red-500">
            <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md mx-4">
                <div className="text-center mb-8">
                    <div className="text-6xl mb-4">🌟</div>
                    <h1 className="text-2xl font-bold text-gray-800 mb-2">Happy Mind</h1>
                    <p className="text-gray-600">Trường học tích cực thông minh</p>
                </div>
                <form id="login-form" className="space-y-6" onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="student-name" className="block text-sm font-medium text-gray-700 mb-2">
                            Họ và tên học sinh
                        </label>
                        <input
                            type="text"
                            id="student-name"
                            name="student-name"
                            required
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                            placeholder="Nhập họ và tên của bạn..."
                        />
                    </div>
                    <button type="submit" className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-4 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105">
                        🚀 Bắt đầu hành trình học tập
                    </button>
                </form>
                <div className="mt-6 text-center text-sm text-gray-500">
                    <p>Chào mừng bạn đến với không gian học tập hạnh phúc! 🌈</p>
                </div>
            </div>
        </div>
    );
};