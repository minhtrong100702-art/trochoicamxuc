
import React from 'react';

export interface ToastData {
    id: number;
    message: string;
}

interface ToastProps {
    toasts: ToastData[];
}

export const Toast: React.FC<ToastProps> = ({ toasts }) => {
    return (
        <div className="fixed top-4 right-4 z-50 space-y-2">
            {toasts.map(toast => (
                <div key={toast.id} className="bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg transition-all duration-300 animate-pulse">
                    {toast.message}
                </div>
            ))}
        </div>
    );
};