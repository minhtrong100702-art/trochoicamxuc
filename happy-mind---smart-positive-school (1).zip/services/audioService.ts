
type SoundType = 'click' | 'zen' | 'happy' | 'mission' | 'celebration' | 'success' | 'error' | 'notification';

interface AudioState {
    audioContext: AudioContext | null;
    oscillators: OscillatorNode[];
    gainNodes: GainNode[];
    stopCallback?: () => void;
}

class AudioService {
    private currentAudio: AudioState | null = null;
    private isPlaying = false;

    private playTone(frequency: number, duration: number, type: OscillatorType = 'sine') {
        try {
            const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
            oscillator.type = type;
            gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration / 1000);
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + duration / 1000);
        } catch (e) {
            console.warn("Web Audio API is not supported in this browser.");
        }
    }
    
    public playSound(type: SoundType) {
        const soundMap: Record<SoundType, () => void> = {
            click: () => this.playTone(800, 100, 'sine'),
            zen: () => this.playTone(432, 500, 'sine'),
            happy: () => this.playChord([523, 659, 784], 300),
            mission: () => this.playSequence([523, 587, 659, 698], 150),
            celebration: () => {
                const melody = [523, 659, 784, 1047, 784, 659, 523];
                melody.forEach((freq, index) => setTimeout(() => this.playTone(freq, 200, 'triangle'), index * 150));
            },
            success: () => this.playSequence([523, 659, 784], 200),
            error: () => this.playTone(200, 300, 'sawtooth'),
            notification: () => this.playChord([440, 554], 250),
        };
        soundMap[type]();
    }
    
    private playChord(frequencies: number[], duration: number) {
        frequencies.forEach((freq, index) => {
            setTimeout(() => this.playTone(freq, duration), index * 50);
        });
    }

    private playSequence(frequencies: number[], noteDuration: number) {
        frequencies.forEach((freq, index) => {
            setTimeout(() => this.playTone(freq, noteDuration), index * noteDuration);
        });
    }

    public playBellSound(count = 1) {
        for (let i = 0; i < count; i++) {
            setTimeout(() => {
                try {
                    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
                    const oscillator = audioContext.createOscillator();
                    const gainNode = audioContext.createGain();
                    oscillator.connect(gainNode);
                    gainNode.connect(audioContext.destination);
                    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                    oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 2);
                    oscillator.type = 'sine';
                    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 3);
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 3);
                } catch (e) {
                     console.warn("Web Audio API is not supported in this browser.");
                }
            }, i * 1000);
        }
    }
    
    public playMelody(notes: number[]) {
        this.stopAllMusic();
        try {
            const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
            let noteIndex = 0;
            const playNextNote = () => {
                if (!this.isPlaying) return;
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                oscillator.frequency.setValueAtTime(notes[noteIndex], audioContext.currentTime);
                oscillator.type = 'triangle';
                gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1);
                oscillator.start();
                oscillator.stop(audioContext.currentTime + 1);
                noteIndex = (noteIndex + 1) % notes.length;
                if (this.isPlaying) {
                    setTimeout(playNextNote, 1500);
                }
            };
            this.currentAudio = { audioContext, oscillators: [], gainNodes: [], stopCallback: () => { this.isPlaying = false; } };
            this.isPlaying = true;
            playNextNote();
        } catch (e) {
            console.warn("Web Audio API is not supported in this browser.");
        }
    }


    public stopAllMusic() {
        if (this.currentAudio) {
            if (this.currentAudio.oscillators) {
                this.currentAudio.oscillators.forEach(osc => {
                    try {
                        osc.stop();
                    } catch (e) { /* Fails silently */ }
                });
            }
            if (this.currentAudio.audioContext) {
                this.currentAudio.audioContext.close().catch(() => {});
            }
            if (this.currentAudio.stopCallback) {
                this.currentAudio.stopCallback();
            }
        }
        this.currentAudio = null;
        this.isPlaying = false;
    }
}

export const audioService = new AudioService();